from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
import os
import logging
import subprocess
import shutil
import glob

# إعداد logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def find_chromium():
    """البحث عن Chromium/Chrome في جميع المسارات الممكنة"""
    
    # ── المسارات الخاصة بـ Nixpacks ──────────────────────────
    nix_paths = glob.glob("/nix/store/*-chromium-*/bin/chromium")
    nix_paths += glob.glob("/nix/store/*-chromium-*/bin/chromium-browser")
    nix_paths += glob.glob("/nix/store/*-google-chrome-*/bin/google-chrome")
    
    for path in nix_paths:
        if path and os.path.exists(path) and os.access(path, os.X_OK):
            logger.info(f"✅ وجدت متصفح Nix: {path}")
            return path
    
    # ── قائمة المسارات المحتملة ──────────────────────────────────
    possible_paths = [
        # Nixpacks
        "/nix/store/*-chromium-*/bin/chromium",
        "/nix/store/*-chromium-*/bin/chromium-browser",
        "/nix/store/*-google-chrome-*/bin/google-chrome",
        "/nix/store/*-google-chrome-*/bin/google-chrome-stable",
        # عامة
        "/usr/bin/chromium",
        "/usr/bin/chromium-browser",
        "/usr/bin/google-chrome",
        "/usr/bin/google-chrome-stable",
        "/usr/bin/chrome",
        # إضافية
        "/opt/google/chrome/chrome",
        "/opt/chromium/chromium",
        # من PATH
        shutil.which("chromium"),
        shutil.which("chromium-browser"),
        shutil.which("google-chrome"),
        shutil.which("google-chrome-stable"),
        shutil.which("chrome"),
    ]
    
    # ── البحث باستخدام wildcard ──────────────────────────────────
    expanded_paths = []
    for path in possible_paths:
        if path and "*" in str(path):
            try:
                expanded = glob.glob(str(path))
                expanded_paths.extend(expanded)
            except Exception as e:
                logger.warning(f"⚠️ خطأ في البحث عن wildcard: {e}")
                pass
        elif path:
            expanded_paths.append(str(path))
    
    # ── التحقق من وجود الملفات ──────────────────────────────────
    for path in expanded_paths:
        if path and os.path.exists(path) and os.access(path, os.X_OK):
            logger.info(f"✅ وجدت متصفح: {path}")
            return path
    
    # ── محاولة إضافية عبر which ──────────────────────────────────
    try:
        for cmd in ["chromium", "chromium-browser", "google-chrome", "chrome"]:
            result = subprocess.run(["which", cmd], capture_output=True, text=True)
            if result.returncode == 0 and result.stdout.strip():
                path = result.stdout.strip()
                if os.path.exists(path):
                    logger.info(f"✅ وجدت متصفح عبر which: {path}")
                    return path
    except:
        pass
    
    logger.warning("⚠️ لم يتم العثور على Chromium/Chrome تلقائياً")
    return None

def create_driver(headless=True):
    """إنشاء سائق ChromeDriver مع إعدادات متوافقة مع VPS"""
    
    options = Options()
    
    # ── الإعدادات الأساسية ──────────────────────────────────────
    if headless:
        options.add_argument("--headless=new")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")
    options.add_argument("--window-size=1920,1080")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--incognito")
    options.add_argument("--disable-webauthn")
    options.add_argument("--disable-extensions")
    options.add_argument("--disable-infobars")
    options.add_argument("--disable-setuid-sandbox")
    options.add_argument("--remote-debugging-port=0")
    options.add_argument("--disable-background-networking")
    options.add_argument("--disable-default-apps")
    options.add_argument("--disable-sync")
    options.add_argument("--disable-translate")
    options.add_argument("--hide-scrollbars")
    options.add_argument("--metrics-recording-only")
    options.add_argument("--mute-audio")
    options.add_argument("--no-first-run")
    options.add_argument("--safebrowsing-disable-auto-update")
    options.add_argument("--disable-component-extensions-with-background-pages")
    options.add_argument("--disable-features=TranslateUI,BlinkGenPropertyTrees")
    options.add_argument("--disable-ipc-flooding-protection")
    options.add_argument("--disable-renderer-backgrounding")
    
    # ── تعطيل WebAuthn ──────────────────────────────────────────
    webauthn_features = [
        "WebAuthentication",
        "WebAuthn",
        "WebAuthenticationAPI",
        "WebAuthenticationSecurityKey",
        "WebAuthenticationUI",
        "WebAuthnNFC",
        "WebAuthnUSB"
    ]
    options.add_argument(f"--disable-features={','.join(webauthn_features)}")
    
    # ── إعدادات إضافية ──────────────────────────────────────────
    prefs = {
        "credentials_enable_autosignin": False,
        "credentials_enable_service": False,
        "webauthn.enable_win_native_api": False,
        "webauthn.enable_usb": False,
        "webauthn.enable_platform_authenticators": False,
        "webauthn.virtual_authenticators_enabled": False,
        "profile.password_manager_enabled": False,
        "profile.default_content_setting_values.notifications": 2,
    }
    options.add_experimental_option("prefs", prefs)
    
    # ── إخفاء الأتمتة ──────────────────────────────────────────
    user_agent = (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36"
    )
    options.add_argument(f"user-agent={user_agent}")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)
    
    # ── البحث عن متصفح ──────────────────────────────────────────
    chromium_path = find_chromium()
    if chromium_path:
        options.binary_location = chromium_path
        logger.info(f"🔍 استخدام المتصفح: {chromium_path}")
    else:
        # محاولة استخدام المسار الافتراضي
        default_paths = ["/usr/bin/chromium-browser", "/snap/bin/chromium", "/usr/bin/chromium"]
        for path in default_paths:
            if os.path.exists(path):
                options.binary_location = path
                logger.info(f"🔍 استخدام المتصفح: {path}")
                break
    
    # ── تحديد مسار chromedriver ──────────────────────────────────
    chromedriver_paths = [
        "/usr/bin/chromedriver",
        "/snap/bin/chromedriver",
        "/usr/lib/chromium-browser/chromedriver",
    ]
    
    service = None
    for path in chromedriver_paths:
        if os.path.exists(path):
            logger.info(f"🔍 استخدام chromedriver: {path}")
            service = Service(path)
            break
    
    if not service:
        # محاولة استخدام chromedriver من PATH
        try:
            import shutil
            chromedriver_in_path = shutil.which("chromedriver")
            if chromedriver_in_path:
                logger.info(f"🔍 استخدام chromedriver من PATH: {chromedriver_in_path}")
                service = Service(chromedriver_in_path)
        except:
            pass
    
    if not service:
        raise RuntimeError("لم يتم العثور على chromedriver! تأكد من تثبيت chromium-chromedriver")
    
    # ── إنشاء السائق ────────────────────────────────────────────
    try:
        logger.info("🚀 إنشاء ChromeDriver...")
        driver = webdriver.Chrome(service=service, options=options)
        logger.info("✅ ChromeDriver يعمل بنجاح!")
        
        # ── حقن إخفاء الأتمتة ──────────────────────────────────────
        try:
            driver.execute_cdp_cmd('Page.addScriptToEvaluateOnNewDocument', {
                'source': '''
                    Object.defineProperty(navigator, 'webdriver', {
                        get: () => undefined
                    });
                    Object.defineProperty(navigator, 'plugins', {
                        get: () => [1, 2, 3, 4, 5]
                    });
                    Object.defineProperty(navigator, 'languages', {
                        get: () => ['en-US', 'en', 'ar']
                    });
                    window.chrome = { runtime: {} };
                    Object.defineProperty(window, 'chrome', {
                        get: () => ({ runtime: {} })
                    });
                '''
            })
            logger.info("✅ تم تطبيق إخفاء الأتمتة")
        except Exception as e:
            logger.warning(f"⚠️ تعذر تطبيق إخفاء الأتمتة: {e}")
        
        return driver
        
    except Exception as e:
        logger.error(f"❌ فشل إنشاء ChromeDriver: {e}")
        raise RuntimeError(f"فشل ChromeDriver: {e}")

# ── اختبار سريع ──────────────────────────────────────────────────
if __name__ == "__main__":
    print("🧪 اختبار إنشاء ChromeDriver...")
    try:
        driver = create_driver(headless=True)
        driver.get("https://www.google.com")
        print(f"✅ الصفحة مفتوحة: {driver.title}")
        driver.quit()
        print("✅ اختبار ناجح!")
    except Exception as e:
        print(f"❌ فشل الاختبار: {e}")