import os
import sys
import shutil
import platform
import time
import subprocess

LINUX_CHROMIUM_PATH = "/nix/store/qa9cnw4v5xkxyip6mb9kxqfq1z4x2dx1-chromium-138.0.7204.100/bin/chromium"

WINDOWS_CHROME_PATHS = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
    os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
    os.path.expandvars(r"%PROGRAMFILES%\Google\Chrome\Application\chrome.exe"),
    os.path.expandvars(r"%PROGRAMFILES(X86)%\Google\Chrome\Application\chrome.exe"),
]

MAC_CHROME_PATHS = [
    "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
    "/Applications/Chromium.app/Contents/MacOS/Chromium",
]


def _detect_chrome_binary():
    system = platform.system()
    if system == "Windows":
        for path in WINDOWS_CHROME_PATHS:
            if path and os.path.exists(path):
                return path
        for cmd in ["chrome", "google-chrome"]:
            p = shutil.which(cmd)
            if p:
                return p
        return None
    elif system == "Darwin":
        for path in MAC_CHROME_PATHS:
            if os.path.exists(path):
                return path
        return None
    else:
        if os.path.exists(LINUX_CHROMIUM_PATH):
            return LINUX_CHROMIUM_PATH
        for cmd in ["chromium", "chromium-browser", "google-chrome"]:
            p = shutil.which(cmd)
            if p:
                return p
        return None


def _get_chrome_major_version(binary_path: str):
    if not binary_path:
        return None
    try:
        flags = 0x08000000 if platform.system() == "Windows" else 0
        result = subprocess.run(
            [binary_path, "--version"],
            capture_output=True, text=True, timeout=6,
            creationflags=flags,
        )
        for token in result.stdout.split():
            if token and token[0].isdigit():
                return int(token.split(".")[0])
    except Exception:
        pass
    return None


def _base_options(opts, binary_path=None):
    """
    Minimal stable Chrome flags.
    IMPORTANT: --no-proxy-server is intentionally omitted.
    On Windows, it breaks DNS resolution (ERR_ADDRESS_INVALID)
    by bypassing the Winsock/WFP DNS stack Chrome depends on.
    """
    opts.add_argument("--headless=new")
    opts.add_argument("--disable-gpu")
    opts.add_argument("--no-sandbox")
    opts.add_argument("--disable-dev-shm-usage")
    opts.add_argument("--window-size=1920,1080")
    opts.add_argument("--disable-blink-features=AutomationControlled")
    opts.add_argument("--disable-webauthn")
    opts.add_argument("--disable-extensions")
    opts.add_argument("--disable-infobars")
    opts.add_argument("--disable-notifications")
    opts.add_argument("--disable-popup-blocking")
    opts.add_argument("--disable-background-timer-throttling")
    opts.add_argument("--disable-renderer-backgrounding")
    opts.add_argument("--remote-allow-origins=*")
    opts.add_argument("--log-level=3")
    opts.add_argument("--silent")

    # Required for networks that block QUIC/HTTP2 (ISP-level blocking).
    # Matches Chrome shortcut flags: --disable-quic --disable-http2
    opts.add_argument("--disable-quic")
    opts.add_argument("--disable-http2")
    opts.add_argument("--disable-features=NetworkServiceInProcess2")

    if platform.system() == "Windows":
        opts.add_argument("--disable-software-rasterizer")
        opts.add_argument("--disable-features=VizDisplayCompositor")

    opts.add_argument(
        "--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36"
    )

    if binary_path:
        opts.binary_location = binary_path

    return opts


def _antidetect(driver):
    try:
        driver.execute_cdp_cmd("Page.addScriptToEvaluateOnNewDocument", {
            "source": (
                "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});"
                "window.navigator.chrome={runtime:{}};"
                "Object.defineProperty(navigator,'plugins',{get:()=>[1,2,3,4,5]});"
                "Object.defineProperty(navigator,'languages',{get:()=>['en-US','en']});"
            )
        })
    except Exception:
        pass


# ──────────────────────────────────────────────
# Strategy 1 — undetected-chromedriver
# Auto-patches to match any Chrome version incl. 149+
# ──────────────────────────────────────────────
def _try_undetected(binary_path):
    try:
        import undetected_chromedriver as uc
    except ImportError:
        print("⚠️  undetected_chromedriver not installed")
        print("   Fix: pip install undetected-chromedriver")
        return None

    try:
        opts = uc.ChromeOptions()
        opts.add_argument("--disable-gpu")
        opts.add_argument("--no-sandbox")
        opts.add_argument("--disable-dev-shm-usage")
        opts.add_argument("--window-size=1920,1080")
        opts.add_argument("--disable-blink-features=AutomationControlled")
        opts.add_argument("--remote-allow-origins=*")
        opts.add_argument("--log-level=3")
        if platform.system() == "Windows":
            opts.add_argument("--disable-software-rasterizer")

        driver = uc.Chrome(
            options=opts,
            headless=True,
            use_subprocess=True,
            browser_executable_path=binary_path or None,
        )
        driver.set_page_load_timeout(60)
        driver.set_script_timeout(30)
        _antidetect(driver)
        print("✅ ChromeDriver via undetected-chromedriver")
        return driver
    except Exception as e:
        print(f"⚠️  undetected-chromedriver failed: {e}")
        return None


# ──────────────────────────────────────────────
# Strategy 2 — Selenium Manager (Selenium 4.6+)
# Downloads ChromeDriver matching INSTALLED Chrome
# ──────────────────────────────────────────────
def _try_selenium_manager(binary_path):
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options

    try:
        opts = Options()
        _base_options(opts, binary_path)
        opts.add_experimental_option("prefs", {
            "credentials_enable_autosignin": False,
            "credentials_enable_service": False,
        })
        opts.add_experimental_option("excludeSwitches", ["enable-automation", "enable-logging"])
        opts.add_experimental_option("useAutomationExtension", False)

        driver = webdriver.Chrome(options=opts)   # no service= → Selenium Manager
        driver.set_page_load_timeout(60)
        driver.set_script_timeout(30)
        driver.implicitly_wait(0)
        _antidetect(driver)
        print("✅ ChromeDriver via Selenium Manager (version-matched)")
        return driver
    except Exception as e:
        print(f"⚠️  Selenium Manager failed: {e}")
        return None


# ──────────────────────────────────────────────
# Strategy 3 — webdriver-manager (last resort)
# Downloads latest stable — may mismatch Chrome 149
# ──────────────────────────────────────────────
def _try_webdriver_manager(binary_path):
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.chrome.service import Service

    try:
        from webdriver_manager.chrome import ChromeDriverManager
        opts = Options()
        _base_options(opts, binary_path)
        opts.add_experimental_option("prefs", {
            "credentials_enable_autosignin": False,
            "credentials_enable_service": False,
        })
        opts.add_experimental_option("excludeSwitches", ["enable-automation", "enable-logging"])
        opts.add_experimental_option("useAutomationExtension", False)

        service = Service(ChromeDriverManager().install())
        driver = webdriver.Chrome(service=service, options=opts)
        driver.set_page_load_timeout(60)
        driver.set_script_timeout(30)
        driver.implicitly_wait(0)
        _antidetect(driver)
        print("✅ ChromeDriver via webdriver-manager")
        return driver
    except Exception as e:
        print(f"⚠️  webdriver-manager failed: {e}")
        return None


# ──────────────────────────────────────────────
# Public entry point
# ──────────────────────────────────────────────
def create_driver(headless: bool = True, retries: int = 2):
    system = platform.system()
    print(f"🚀 Creating ChromeDriver  [platform: {system}]")

    binary_path = _detect_chrome_binary()
    if binary_path:
        ver = _get_chrome_major_version(binary_path)
        print(f"🔍 Chrome binary: {binary_path}")
        if ver:
            print(f"🔍 Chrome version: {ver}")
            if ver >= 149:
                print("⚠️  Chrome 149+ (Canary/Dev). Strongly recommend:")
                print("   pip install undetected-chromedriver --upgrade")

    for attempt in range(1, retries + 1):
        driver = _try_undetected(binary_path)
        if driver:
            return driver

        driver = _try_selenium_manager(binary_path)
        if driver:
            return driver

        driver = _try_webdriver_manager(binary_path)
        if driver:
            return driver

        if attempt < retries:
            print(f"⏳ All strategies failed (attempt {attempt}) — retrying in 3s...")
            time.sleep(3)

    raise RuntimeError(
        "❌ ChromeDriver initialization failed.\n\n"
        "Run these then retry:\n"
        "  pip install undetected-chromedriver --upgrade\n"
        "  pip install selenium --upgrade\n\n"
        "If on Chrome 149 (Canary/Dev), switch to Chrome Stable:\n"
        "  https://www.google.com/chrome/"
    )
