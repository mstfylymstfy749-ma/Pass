cat > /root/Pass/automation/driver.py << 'EOF'
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service
import os
import platform

def create_driver(headless=True):
    options = Options()
    
    if headless:
        options.add_argument("--headless=new")
    else:
        options.add_argument("--start-minimized")
    
    options.add_argument("--disable-gpu")
    options.add_argument("--window-size=1920,1080")
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--incognito")
    options.add_argument("--disable-webauthn")
    options.add_argument("--disable-features=WebAuthentication,WebAuthn")
    
    # تحديد وكيل المستخدم
    system = platform.system().lower()
    if system == 'linux':
        user_agent = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36"
    else:
        user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36"
    
    options.add_argument(f"user-agent={user_agent}")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    options.add_experimental_option("useAutomationExtension", False)
    
    # البحث عن متصفح Chrome/Chromium
    chrome_paths = [
        "/usr/bin/google-chrome",
        "/usr/bin/google-chrome-stable", 
        "/usr/bin/chromium-browser",
        "/usr/bin/chromium",
        "/opt/google/chrome/chrome",
        "/snap/bin/chromium"
    ]
    
    found_chrome = False
    for chrome_path in chrome_paths:
        if os.path.exists(chrome_path):
            options.binary_location = chrome_path
            print(f"🔍 Found Chrome at: {chrome_path}")
            found_chrome = True
            break
    
    if not found_chrome:
        print("⚠️ Chrome/Chromium not found! Make sure it's installed.")
    
    # ── تحديد مسار chromedriver مباشرة ──────────────────────────────────
    chromedriver_paths = [
        "/usr/bin/chromedriver",
        "/usr/lib/chromium-browser/chromedriver",
        "/snap/bin/chromedriver",
    ]
    
    service = None
    for path in chromedriver_paths:
        if os.path.exists(path):
            print(f"🔍 Found chromedriver at: {path}")
            service = Service(path)
            break
    
    # إذا لم يتم العثور على chromedriver، حاول استخدام webdriver-manager
    if not service:
        print("⚠️ chromedriver not found in system, trying webdriver-manager...")
        try:
            from webdriver_manager.chrome import ChromeDriverManager
            service = Service(ChromeDriverManager().install())
            print(f"✅ chromedriver downloaded via webdriver-manager")
        except Exception as e:
            print(f"❌ webdriver-manager failed: {e}")
            raise RuntimeError("No chromedriver found. Install: apt install -y chromium-chromedriver")
    
    try:
        driver = webdriver.Chrome(service=service, options=options)
        print("✅ ChromeDriver initialized successfully")
    except Exception as e:
        print(f"❌ ChromeDriver initialization failed: {e}")
        raise e
    
    # ── إخفاء الأتمتة ──────────────────────────────────────────────────
    try:
        driver.execute_cdp_cmd(
            'Page.addScriptToEvaluateOnNewDocument',
            {
                'source': '''
                    Object.defineProperty(navigator, 'webdriver', {
                        get: () => undefined
                    });
                    window.navigator.chrome = { runtime: {} };
                    Object.defineProperty(navigator, 'plugins', {
                        get: () => [1, 2, 3]
                    });
                    Object.defineProperty(navigator, 'languages', {
                        get: () => ['en-US', 'en']
                    });
                '''
            }
        )
    except Exception as e:
        print(f"⚠️ Could not set anti-detection measures: {e}")
    
    return driver
EOF