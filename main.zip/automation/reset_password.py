from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from automation.driver import create_driver
import time
import random
import string


def clean_text(text):
    if not text:
        return ""
    return "".join(c for c in str(text) if ord(c) <= 0xFFFF)


def _generate_fallback_password():
    chars = string.ascii_letters + string.digits + "!@#$"
    suffix = "".join(random.choices(string.digits, k=6))
    return f"GrimX{suffix}!"


def _fill_password_fields(driver, wait, new_password):
    pwd = wait.until(EC.presence_of_element_located((By.ID, "iPassword")))
    pwd.clear()
    pwd.send_keys(clean_text(new_password))

    retype = wait.until(EC.presence_of_element_located((By.ID, "iRetypePassword")))
    retype.clear()
    retype.send_keys(clean_text(new_password))
    return retype


def perform_password_reset(resetlink: str, email: str, new_password: str) -> str | None:
    print("🔁 Starting password reset flow...")

    driver = create_driver()
    wait   = WebDriverWait(driver, 30)

    try:
        driver.get(resetlink)
        print("🔗 Reset link opened")
        time.sleep(2)

        # Some links land directly on password form, some need email re-entry
        try:
            email_input = WebDriverWait(driver, 8).until(
                EC.presence_of_element_located((By.ID, "AccountNameInput"))
            )
            email_input.clear()
            email_input.send_keys(clean_text(email))
            email_input.send_keys(Keys.RETURN)
            print("📨 Email submitted on reset page")
            time.sleep(2)
        except TimeoutException:
            print("ℹ️ No email field — probably landed directly on password form")

        # Fill new password
        retype = _fill_password_fields(driver, wait, new_password)
        print(f"🔑 Password fields filled with: {new_password}")
        time.sleep(0.5)
        retype.send_keys(Keys.RETURN)
        print("⏳ Waiting for confirmation...")
        time.sleep(5)

        # Check if "previous password" rejection appeared
        try:
            driver.find_element(By.CSS_SELECTOR, 'input[data-nuid="PreviousPasswordInput"]')
            print("⚠️ Password was previously used — switching to fallback")
            fallback = _generate_fallback_password()
            retype = _fill_password_fields(driver, wait, fallback)
            retype.send_keys(Keys.RETURN)
            time.sleep(4)
            print(f"✅ Fallback password applied: {fallback}")
            return fallback
        except Exception:
            pass

        # Verify success — look for confirmation text
        page_src = driver.page_source.lower()
        success_phrases = [
            "password has been changed",
            "password changed successfully",
            "you can now sign in",
            "your account password has been reset",
        ]
        if any(phrase in page_src for phrase in success_phrases):
            print(f"✅ Password reset confirmed: {new_password}")
            return new_password

        # Inconclusive — still return the password (no error found either)
        print("ℹ️ No explicit confirmation found — assuming reset succeeded")
        return new_password

    except TimeoutException as te:
        print(f"❌ Timeout during password reset: {te}")
        return None
    except Exception as e:
        print(f"❌ Password reset failed: {e}")
        return None
    finally:
        try:
            driver.quit()
        except Exception:
            pass
