from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait, Select
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
from tempmail import get_otp_from_first_email, wait_for_emails, read_message, extract_specific_link, get_messages
from automation.captcha import download_captcha, refresh_captcha
from datetime import datetime
import time
import os
import json


def clean_text(text):
    if not text:
        return ""
    return "".join(c for c in str(text) if ord(c) <= 0xFFFF)


def get_month_name(date_str):
    try:
        date_obj = datetime.strptime(date_str, "%m/%d/%Y")
        return date_obj.strftime("%B"), str(date_obj.day), str(date_obj.year)
    except ValueError:
        print(f"⚠️ Could not parse DOB '{date_str}' — using fallback")
        return "January", "1", "1990"


def _safe_select(driver, element_id, value, label="field", wait_secs=10):
    el = WebDriverWait(driver, wait_secs).until(
        EC.presence_of_element_located((By.ID, element_id))
    )
    sel = Select(el)
    options = [o.text.strip() for o in sel.options]
    # Exact match first
    if value in options:
        sel.select_by_visible_text(value)
        return True
    # Partial match
    for opt in options:
        if opt.startswith(value[:3]):
            sel.select_by_visible_text(opt)
            print(f"⚠️ {label}: partial match '{opt}' for '{value}'")
            return True
    print(f"❌ {label}: '{value}' not in options {options}")
    return False


def _submit_captcha_and_wait_otp(driver, captcha_text):
    """Submit captcha, return ('ok', otp_value) or ('retry', None) or ('fail', None)."""
    try:
        captcha_input = WebDriverWait(driver, 12).until(
            EC.presence_of_element_located((By.XPATH, '//input[contains(@id, "SolutionElement")]'))
        )
        captcha_input.clear()
        captcha_input.send_keys(clean_text(captcha_text.strip()))
        captcha_input.send_keys(Keys.RETURN)
        print("📨 CAPTCHA submitted — waiting for OTP field...")

        # Confirm OTP field appeared (means captcha was accepted)
        WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "iOttText"))
        )
        print("✅ CAPTCHA accepted — OTP field visible")
        return "ok", None

    except TimeoutException:
        print("❌ CAPTCHA rejected or OTP field not found — requesting new captcha")
        new_img = refresh_captcha(driver)
        if new_img:
            return "retry", new_img
        return "fail", None
    except Exception as e:
        print(f"❌ Captcha submit unexpected error: {e}")
        return "fail", None


def continue_acsr_flow(driver, account_info, token, captcha_text):
    wait = WebDriverWait(driver, 20)

    try:
        status, retry_img = _submit_captcha_and_wait_otp(driver, captcha_text)
        if status == "retry":
            print("🔁 New CAPTCHA ready — need user re-submission")
            return {"status": "CAPTCHA_RETRY_NEEDED", "captcha_image": retry_img}
        if status == "fail":
            return {"status": "CAPTCHA_DOWNLOAD_FAILED"}

        # Fetch OTP with exponential backoff
        print("⌛ Waiting for OTP via temp mail...")
        otp = None
        for attempt in range(1, 7):
            otp = get_otp_from_first_email(token)
            if otp:
                print(f"📥 OTP received: {otp}")
                break
            wait_time = min(10 * attempt, 60)
            print(f"⏳ OTP not yet received (attempt {attempt}/6) — waiting {wait_time}s...")
            time.sleep(wait_time)

        if not otp:
            return {"status": "error", "message": "❌ OTP not received after 6 attempts"}

        # Submit OTP
        code_input = wait.until(EC.presence_of_element_located((By.ID, "iOttText")))
        code_input.clear()
        code_input.send_keys(clean_text(otp))
        code_input.send_keys(Keys.RETURN)
        print("🔐 OTP submitted")
        time.sleep(2)

        # Fill name
        name_cleaned = clean_text(account_info.get("name", "User"))
        if " " in name_cleaned:
            first, last = name_cleaned.split(maxsplit=1)
        else:
            first, last = name_cleaned, "User"

        wait.until(EC.presence_of_element_located((By.ID, "FirstNameInput"))).send_keys(first)
        wait.until(EC.presence_of_element_located((By.ID, "LastNameInput"))).send_keys(last)
        print(f"🧾 Name filled: {first} {last}")

        # DOB
        dob_str = account_info.get("dob", "01/01/1990")
        month, day, year = get_month_name(dob_str)
        print(f"📆 DOB parsing: month={month}, day={day}, year={year}")

        _safe_select(driver, "BirthDate_dayInput",   day,   "Day")
        _safe_select(driver, "BirthDate_monthInput", month, "Month")
        _safe_select(driver, "BirthDate_yearInput",  year,  "Year")
        print("📆 DOB filled")

        # Region
        region_input = wait.until(EC.presence_of_element_located((By.ID, "CountryInput")))
        region_input.clear()
        region_input.send_keys(clean_text(account_info.get("region", "")))
        print(f"🌍 Region filled: {account_info.get('region', '')}")
        time.sleep(1)

        # Submit name section
        driver.find_element(By.ID, "FirstNameInput").send_keys(Keys.RETURN)
        time.sleep(1)

        # Old password
        print("🔐 Entering old password...")
        prev_pass = WebDriverWait(driver, 12).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'input[data-nuid="PreviousPasswordInput"]'))
        )
        prev_pass.clear()
        prev_pass.send_keys(clean_text(account_info.get("password", "")))
        print("✅ Old password entered")
        time.sleep(1)

        # Skype checkbox
        try:
            skype_cb = driver.find_element(By.ID, "ProductOptionSkype")
            if not skype_cb.is_selected():
                skype_cb.click()
                print("☑️ Skype selected")
        except NoSuchElementException:
            print("⚠️ Skype checkbox not found — skipping")

        # Xbox checkbox
        try:
            xbox_cb = driver.find_element(By.ID, "ProductOptionXbox")
            if not xbox_cb.is_selected():
                xbox_cb.click()
                print("🎮 Xbox selected")
        except NoSuchElementException:
            print("⚠️ Xbox checkbox not found — skipping")

        # Submit to move to Skype fields
        prev_pass.send_keys(Keys.RETURN)

        # Skype info
        try:
            skype_name = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "SkypeNameInput"))
            )
            skype_name.clear()
            skype_name.send_keys(clean_text(account_info.get("skype_id", "live:")))

            skype_email_input = wait.until(
                EC.presence_of_element_located((By.ID, "SkypeAccountCreateEmailInput"))
            )
            skype_email_input.clear()
            skype_email_input.send_keys(clean_text(account_info.get("skype_email", account_info["email"])))
            print("🔑 Skype info filled")
            time.sleep(1)
            skype_email_input.send_keys(Keys.RETURN)
        except TimeoutException:
            print("⚠️ Skype fields not found — skipping")

        # Xbox product
        try:
            xbox_radio = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "XboxOneOption"))
            )
            if not xbox_radio.is_selected():
                xbox_radio.click()
            xbox_radio.send_keys(Keys.ENTER)
            print("✅ Xbox One selected")
            time.sleep(2)

            xbox_gt = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "XboxGamertagInput"))
            )
            xbox_gt.clear()
            xbox_gt.send_keys(clean_text(account_info.get("gamertag", "")))
            xbox_gt.send_keys(Keys.RETURN)
            print("✅ Gamertag submitted")
        except TimeoutException:
            print("⚠️ Xbox fields not found — skipping")

        time.sleep(2)

        # Check for "too many requests" error
        try:
            err_el = WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.XPATH,
                    "//div[contains(text(), \"You've reached the limit for account recovery requests\")]"
                ))
            )
            if err_el.is_displayed():
                print("❌ Too many recovery requests today")
                return {"status": "error", "message": "❌ Too many recovery requests today"}
        except TimeoutException:
            pass

        # Fetch reset link from inbox
        print("📬 Waiting for reset emails (up to 3 min)...")
        emails = None
        for i in range(18):
            print(f"📧 Inbox check {i+1}/18...")
            emails = get_messages(token)
            if len(emails) >= 2:
                print(f"✅ {len(emails)} emails in inbox")
                break
            time.sleep(10)

        if not emails or len(emails) < 2:
            print(f"⚠️ Only {len(emails) if emails else 0} email(s) — trying anyway...")
            emails = emails or []

        reset_link = None
        for email_item in reversed(emails):
            try:
                msg = read_message(token, email_item["id"])
                subject = email_item.get("subject", "")
                print(f"📧 Scanning email: {subject}")

                text_content = msg.get("text", "") or ""
                html_content = msg.get("html", "") or ""

                if isinstance(text_content, list):
                    text_content = "\n".join(str(x) for x in text_content)
                if isinstance(html_content, list):
                    html_content = "\n".join(str(x) for x in html_content)

                reset_link = extract_specific_link(text_content, html_content)
                if reset_link:
                    print(f"✅ Reset link found in: {subject}")
                    break
            except Exception as ex:
                print(f"⚠️ Email read error: {ex}")

        try:
            driver.quit()
        except Exception:
            pass

        if reset_link:
            print(f"🔗 Reset link: {reset_link[:80]}...")
            return {"status": "success", "reset_link": reset_link}
        else:
            print("❌ No reset link found in emails")
            for em in (emails or []):
                print(f"  - Subject: {em.get('subject', 'N/A')}")
            return {"status": "error", "message": "❌ Reset link not found in inbox"}

    except Exception as e:
        print(f"❌ ACSR continue flow error: {e}")
        try:
            driver.quit()
        except Exception:
            pass
        return {"status": "error", "message": f"❌ Unexpected error: {str(e)[:200]}"}
