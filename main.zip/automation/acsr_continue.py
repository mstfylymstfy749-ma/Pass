from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from tempmail import get_otp_from_first_email, wait_for_emails, read_message, extract_specific_link, get_messages
from datetime import datetime
from automation.captcha import download_captcha
import time
import os
import json

def clean_text(text):
    """Remove non-BMP characters that ChromeDriver doesn't support."""
    if not text:
        return ""
    return ''.join(c for c in str(text) if ord(c) <= 0xFFFF)

def get_month_name(date_str):
    try:
        date_obj = datetime.strptime(date_str, "%m/%d/%Y")
        month_name = date_obj.strftime("%B")
        day = str(date_obj.day)
        year = str(date_obj.year)
        return month_name, day, year
    except ValueError:
        return "May", "5", "1989"

def should_save_emails():
    """Check if email saving is enabled in config.json"""
    try:
        config_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "config.json"
        )
        with open(config_path, 'r') as f:
            config = json.load(f)
            return config.get("save_emails_to_file", False)
    except:
        return False

def continue_acsr_flow(driver, account_info, token, captcha_text):
    wait = WebDriverWait(driver, 20)

    try:
        captcha_value = clean_text(captcha_text)

        try:
            captcha_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, '//input[contains(@id, "SolutionElement")]'))
            )
            captcha_input.clear()
            captcha_input.send_keys(captcha_value)
            captcha_input.send_keys(Keys.RETURN)
            print("📨 CAPTCHA submitted. Waiting for OTP input field...")

            code_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "iOttText"))
            )
            print("✅ CAPTCHA accepted.")

        except Exception:
            print("❌ CAPTCHA failed or OTP input not found.")
            print("🔁 Waiting for new CAPTCHA to regenerate...\n")

            try:
                captcha_image = download_captcha(driver)
                print("🧩 New CAPTCHA downloaded.")
                with open(f"captcha_retry.png", "wb") as f:
                    f.write(captcha_image.read())
                return "CAPTCHA_RETRY_NEEDED"
            except Exception as e:
                print(f"❌ Failed to detect new CAPTCHA image: {e}")
                return "CAPTCHA_DOWNLOAD_FAILED"

        print("⌛ Waiting for OTP via tempmail...")
        otp = get_otp_from_first_email(token)
        if not otp:
            print("❌ OTP not received.")
            return "❌ OTP not received."

        print(f"📥 OTP received: {otp}")

        code_input = wait.until(EC.presence_of_element_located((By.ID, "iOttText")))
        code_input.clear()
        code_input.send_keys(clean_text(otp))
        code_input.send_keys(Keys.RETURN)
        print("🔐 OTP submitted.")
        time.sleep(2)

        # Step 5: Fill name
        print("🧾 Filling name...")
        name_cleaned = clean_text(account_info.get('name', 'User'))
        first, last = name_cleaned.split(maxsplit=1) if ' ' in name_cleaned else (name_cleaned, "Last")
        
        try:
            first_name_input = WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.ID, "FirstNameInput"))
            )
            first_name_input.clear()
            first_name_input.send_keys(first)
            time.sleep(0.5)
            
            last_name_input = WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.ID, "LastNameInput"))
            )
            last_name_input.clear()
            last_name_input.send_keys(last)
            time.sleep(0.5)
        except Exception as e:
            print(f"⚠️ Error filling name: {e}")

        month, day, year = get_month_name(account_info['dob'])

        if not all([month, day, year]):
            raise ValueError("❌ Invalid or missing DOB, aborting ACSR form.")

        try:
            day_element = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "BirthDate_dayInput"))
            )
            Select(day_element).select_by_visible_text(day)

            month_element = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "BirthDate_monthInput"))
            )
            Select(month_element).select_by_visible_text(month)

            year_element = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "BirthDate_yearInput"))
            )
            Select(year_element).select_by_visible_text(year)
            print(f"📆 DOB filled: {month}/{day}/{year}")
        except Exception as e:
            print(f"⚠️ Error filling DOB: {e}")

        try:
            country_input = WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.ID, "CountryInput"))
            )
            country_input.clear()
            country_input.send_keys(clean_text(account_info['region']))
            print("🌍 Region filled.")
        except Exception as e:
            print(f"⚠️ Error filling region: {e}")

        time.sleep(1)

        try:
            first_name_input = driver.find_element(By.ID, "FirstNameInput")
            first_name_input.send_keys(Keys.RETURN)
            time.sleep(1)
        except:
            pass

        print("🔐 Entering old password...")
        try:
            previous_pass_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, 'input[data-nuid="PreviousPasswordInput"]'))
            )
            previous_pass_input.clear()
            previous_pass_input.send_keys(clean_text(account_info["password"]))
            print("✅ Old password entered.")
        except Exception as e:
            print(f"⚠️ Error entering old password: {e}")

        time.sleep(2)

        try:
            skype_checkbox = driver.find_element(By.ID, "ProductOptionSkype")
            if not skype_checkbox.is_selected():
                skype_checkbox.click()
                print("☑️ Skype option selected.")
        except:
            pass

        try:
            xbox_checkbox = driver.find_element(By.ID, "ProductOptionXbox")
            if not xbox_checkbox.is_selected():
                xbox_checkbox.click()
                print("🎮 Xbox option selected.")
        except:
            pass

        try:
            previous_pass_input.send_keys(Keys.RETURN)
            skype_name_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "SkypeNameInput"))
            )
            skype_name_input.clear()
            skype_name_input.send_keys(clean_text(account_info["skype_id"]))

            skype_email_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "SkypeAccountCreateEmailInput"))
            )
            skype_email_input.clear()
            skype_email_input.send_keys(clean_text(account_info["skype_email"]))
            print("🔑 Skype info filled.")
            time.sleep(2)
            skype_email_input.send_keys(Keys.RETURN)
        except Exception as e:
            print(f"⚠️ Error filling Skype info: {e}")

        try:
            print("🎮 Selecting Xbox One...")
            xbox_radio = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "XboxOneOption"))
            )
            if not xbox_radio.is_selected():
                xbox_radio.click()
            xbox_radio.send_keys(Keys.ENTER)
            print("✅ Xbox One selected.")
            time.sleep(2)
        except Exception as e:
            print(f"⚠️ Error selecting Xbox: {e}")

        try:
            print("🎮 Entering Xbox Gamertag...")
            xbox_name_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "XboxGamertagInput"))
            )
            xbox_name_input.clear()
            xbox_name_input.send_keys(clean_text(account_info["gamertag"]))
            xbox_name_input.send_keys(Keys.RETURN)
            print("✅ Gamertag submitted.")
        except Exception as e:
            print(f"⚠️ Error entering Gamertag: {e}")

        time.sleep(1)
        try:
            error_msg = WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.XPATH, "//div[contains(text(), \"You've reached the limit for account recovery requests\")]"))
            )
            if error_msg.is_displayed():
                print("❌ Failed (too many requests today)")
                try:
                    driver.quit()
                except Exception:
                    pass
                return "❌ Failed (too many requests today)"
        except Exception:
            pass

        try:
            print("📬 Fetching password reset link from temp mail...")
            
            emails = None
            for i in range(20):
                print(f"📧 Checking for emails (attempt {i+1}/20)...")
                emails = get_messages(token)
                if len(emails) >= 2:
                    print(f"✅ Found {len(emails)} emails!")
                    break
                print(f"⏳ Only {len(emails)} email(s) found. Waiting 10 seconds before next check...")
                time.sleep(10)
            
            if len(emails) >= 2:
                resetlink = None
                for email_item in emails:
                    try:
                        msg = read_message(token, email_item['id'])
                        subject = email_item.get('subject', '')
                        print(f"📧 Checking email: {subject}")
                        text_content = msg.get('text', '') or ''
                        html_content = msg.get('html', '') or ''
                        if isinstance(text_content, list):
                            text_content = '\n'.join(str(x) for x in text_content)
                        if isinstance(html_content, list):
                            html_content = '\n'.join(str(x) for x in html_content)
                        resetlink = extract_specific_link(text_content, html_content)
                        if resetlink:
                            print(f"✅ Found reset link in email: {subject}")
                            break
                    except Exception as ex:
                        print(f"⚠️ Error reading email: {ex}")
                        continue

                try:
                    driver.quit()
                except Exception:
                    pass

                if resetlink:
                    print(f"🔗 Target Link: {resetlink}")
                    return resetlink
                else:
                    print("❌ Target reset link not found in any email.")
                    for em in emails:
                        print(f"  - Subject: {em.get('subject', 'N/A')} | From: {em.get('from', {}).get('address', 'N/A')}")
                    return None
            else:
                try:
                    driver.quit()
                except Exception:
                    pass
                print("❌ No new email received after 200 seconds.")
                return None
        except Exception as e:
            print(f"❌ Failed to fetch or extract reset link: {e}")
            return None

    except Exception as e:
        print(f"❌ Error while continuing ACSR flow: {e}")
        return None