from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from PIL import Image
import requests
import time
from io import BytesIO


CAPTCHA_SELECTORS = [
    (By.XPATH,       '//img[contains(@src, "GetHIPData")]'),
    (By.XPATH,       '//img[contains(@src, "hip")]'),
    (By.XPATH,       '//img[contains(@src, "captcha")]'),
    (By.CSS_SELECTOR,'img[src*="GetHIPData"]'),
    (By.CSS_SELECTOR,'img[src*="hip"]'),
    (By.ID,          "hipImg"),
    (By.CLASS_NAME,  "hip-solution"),
]


def download_captcha(driver, retries: int = 3, wait_secs: int = 5) -> BytesIO | None:
    for attempt in range(1, retries + 1):
        try:
            captcha_img = None
            for selector in CAPTCHA_SELECTORS:
                try:
                    captcha_img = WebDriverWait(driver, wait_secs).until(
                        EC.presence_of_element_located(selector)
                    )
                    if captcha_img and captcha_img.is_displayed():
                        print(f"🧩 Captcha element found via {selector[1]}")
                        break
                    captcha_img = None
                except Exception:
                    captcha_img = None

            if captcha_img is None:
                print(f"⚠️ Captcha element not found (attempt {attempt}/{retries})")
                if attempt < retries:
                    time.sleep(2)
                continue

            src = captcha_img.get_attribute("src")
            if not src:
                print("⚠️ Captcha src is empty — skipping attempt")
                if attempt < retries:
                    time.sleep(2)
                continue

            # Fetch image — reuse session cookies
            session = requests.Session()
            for cookie in driver.get_cookies():
                session.cookies.set(cookie["name"], cookie["value"], domain=cookie.get("domain", ""))

            headers = {
                "User-Agent": driver.execute_script("return navigator.userAgent;"),
                "Referer": driver.current_url,
            }
            resp = session.get(src, headers=headers, timeout=15)
            resp.raise_for_status()

            img = Image.open(BytesIO(resp.content)).convert("RGB")
            buf = BytesIO()
            img.save(buf, format="PNG")
            buf.seek(0)

            print(f"✅ Captcha downloaded successfully ({len(resp.content)} bytes)")
            return buf

        except Exception as e:
            print(f"❌ Captcha download attempt {attempt}/{retries} failed: {e}")
            if attempt < retries:
                time.sleep(2)

    print("❌ All captcha download attempts exhausted")
    return None


def refresh_captcha(driver) -> BytesIO | None:
    """Click the captcha audio/refresh button and download the new image."""
    try:
        for selector in [
            (By.XPATH, '//a[contains(@href, "HIP")]'),
            (By.XPATH, '//button[@id="hipRefreshButton"]'),
            (By.XPATH, '//*[@title="New challenge"]'),
            (By.XPATH, '//*[contains(@class, "hip-refresh")]'),
        ]:
            try:
                btn = driver.find_element(*selector)
                if btn.is_displayed():
                    btn.click()
                    print("🔄 Captcha refresh clicked")
                    time.sleep(2)
                    break
            except Exception:
                pass
    except Exception as e:
        print(f"⚠️ Could not refresh captcha: {e}")

    return download_captcha(driver)
