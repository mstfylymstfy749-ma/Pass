from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from automation.captcha import download_captcha
from tempmail import generate_temp_mail_account
import time
from automation.driver import create_driver


def submit_acsr_form(account_info: dict):
    email     = account_info.get("email", "")
    temp_mail_addr, temp_pass, token = None, None, None

    for attempt in range(1, 4):
        try:
            temp_mail_addr, temp_pass, token = generate_temp_mail_account()
            if temp_mail_addr and token:
                print(f"📩 Temp mail ready: {temp_mail_addr}")
                break
        except Exception as e:
            print(f"⚠️ Temp mail attempt {attempt}/3 failed: {e}")
            time.sleep(2)

    if not temp_mail_addr or not token:
        print("❌ Could not generate temp mail after 3 attempts")
        return None, None, None, None

    driver = create_driver()
    wait   = WebDriverWait(driver, 25)

    try:
        print("🌐 Opening ACSR page...")
        driver.get("https://account.live.com/acsr")
        time.sleep(2)

        # Microsoft account email
        ms_email_input = wait.until(
            EC.presence_of_element_located((By.ID, "AccountNameInput"))
        )
        ms_email_input.clear()
        ms_email_input.send_keys(email)
        print(f"✉️ MS email entered: {email}")

        # Temp mail field
        temp_input = wait.until(
            EC.presence_of_element_located((By.ID, "iCMailInput"))
        )
        temp_input.clear()
        temp_input.send_keys(temp_mail_addr)
        print(f"📨 Temp mail entered: {temp_mail_addr}")

        # Download CAPTCHA
        time.sleep(1)
        captcha_image = download_captcha(driver, retries=4, wait_secs=8)
        if captcha_image is None:
            print("❌ CAPTCHA not found on ACSR page")
            driver.quit()
            return None, None, None, None

        print("🧩 CAPTCHA ready for user input")
        return captcha_image, driver, token, temp_mail_addr

    except TimeoutException as te:
        print(f"❌ Timeout on ACSR form: {te}")
        try:
            driver.quit()
        except Exception:
            pass
        return None, None, None, None

    except Exception as e:
        print(f"❌ ACSR submission error: {e}")
        try:
            driver.quit()
        except Exception:
            pass
        return None, None, None, None
