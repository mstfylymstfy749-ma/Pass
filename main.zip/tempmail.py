import requests
import random
import string
import time
import re
from typing import Optional

BASE_URL = "https://api.mail.tm"
TIMEOUT  = 15

HEADERS_JSON = {"Content-Type": "application/json", "Accept": "application/json"}


def _session() -> requests.Session:
    s = requests.Session()
    s.headers.update(HEADERS_JSON)
    return s


def _retry(fn, retries=4, delay=3):
    last = None
    for i in range(retries):
        try:
            return fn()
        except Exception as e:
            last = e
            print(f"⚠️ Retry {i+1}/{retries} — {e}")
            time.sleep(delay * (i + 1))
    raise last


def random_name(length=12):
    return "".join(random.choices(string.ascii_lowercase + string.digits, k=length))


def get_domains() -> str:
    def _call():
        r = requests.get(f"{BASE_URL}/domains", timeout=TIMEOUT)
        r.raise_for_status()
        members = r.json().get("hydra:member", [])
        if not members:
            raise ValueError("No domains returned from mail.tm")
        return members[0]["domain"]
    return _retry(_call)


def register_account(email: str, password: str) -> bool:
    def _call():
        r = requests.post(
            f"{BASE_URL}/accounts",
            json={"address": email, "password": password},
            timeout=TIMEOUT,
        )
        return r.status_code in (201, 422)
    return _retry(_call, retries=3)


def get_token(email: str, password: str) -> str:
    def _call():
        r = requests.post(
            f"{BASE_URL}/token",
            json={"address": email, "password": password},
            timeout=TIMEOUT,
        )
        r.raise_for_status()
        token = r.json().get("token")
        if not token:
            raise ValueError("No token in response")
        return token
    return _retry(_call)


def get_messages(token: str) -> list:
    def _call():
        r = requests.get(
            f"{BASE_URL}/messages",
            headers={"Authorization": f"Bearer {token}"},
            timeout=TIMEOUT,
        )
        r.raise_for_status()
        return r.json().get("hydra:member", [])
    try:
        return _retry(_call, retries=3, delay=2)
    except Exception as e:
        print(f"❌ get_messages failed: {e}")
        return []


def read_message(token: str, message_id: str) -> dict:
    def _call():
        r = requests.get(
            f"{BASE_URL}/messages/{message_id}",
            headers={"Authorization": f"Bearer {token}"},
            timeout=TIMEOUT,
        )
        r.raise_for_status()
        data = r.json()
        if isinstance(data, list) and data:
            data = data[0]
        if not isinstance(data, dict):
            return {"text": "", "html": ""}
        for field in ("text", "html"):
            val = data.get(field, "")
            if isinstance(val, list):
                data[field] = "\n".join(str(x) for x in val)
            elif not isinstance(val, str):
                data[field] = str(val) if val else ""
        return data
    try:
        return _retry(_call, retries=3, delay=2)
    except Exception as e:
        print(f"❌ read_message failed: {e}")
        return {"text": "", "html": ""}


def generate_temp_mail_account() -> tuple[str, str, str]:
    domain   = get_domains()
    username = random_name()
    password = random_name(14)
    email    = f"{username}@{domain}"

    register_account(email, password)
    token = get_token(email, password)
    print(f"✅ Temp mail created: {email}")
    return email, password, token


def wait_for_emails(token: str, expected_count=2, timeout=120, interval=8) -> list:
    attempts = max(1, timeout // interval)
    for i in range(attempts):
        inbox = get_messages(token)
        if len(inbox) >= expected_count:
            print(f"✅ {len(inbox)} email(s) received after {i * interval}s")
            return inbox[:expected_count]
        print(f"⏳ Inbox check {i+1}/{attempts}: {len(inbox)}/{expected_count} email(s)")
        time.sleep(interval)
    return get_messages(token)


def extract_otp(text: str) -> Optional[str]:
    if not text:
        return None
    # Prefer isolated 6-digit sequences
    matches = re.findall(r'(?<!\d)(\d{6})(?!\d)', text)
    return matches[0] if matches else None


def get_otp_from_first_email(token: str, max_wait=90) -> Optional[str]:
    start = time.time()
    interval = 8
    attempts = max(1, max_wait // interval)

    for i in range(attempts):
        emails = get_messages(token)
        if emails:
            msg = read_message(token, emails[0]["id"])
            otp = extract_otp(msg.get("text", "")) or extract_otp(msg.get("html", ""))
            if otp:
                print(f"📥 OTP extracted: {otp}")
                return otp
        elapsed = time.time() - start
        remaining = max_wait - elapsed
        if remaining <= 0:
            break
        wait = min(interval, remaining)
        print(f"⏳ OTP not yet received (attempt {i+1}/{attempts}) — waiting {wait:.0f}s...")
        time.sleep(wait)

    print("❌ OTP not received within timeout")
    return None


def _is_valid_reset_link(url: str) -> bool:
    if not url or len(url) < 40:
        return False
    acsr_paths = [
        "account.live.com/acsr",
        "account.live.com/password/reset",
        "account.live.com/recover",
    ]
    for path in acsr_paths:
        if path in url and "?" in url:
            return True
    ms_domains = [
        "account.live.com",
        "account.microsoft.com",
        "login.live.com",
        "login.microsoftonline.com",
    ]
    if not any(d in url for d in ms_domains):
        return False
    has_token = bool(re.search(r"[?&][A-Za-z_]{1,20}=[A-Za-z0-9%._\-]{8,}", url))
    return has_token and len(url) >= 60


def extract_specific_link(text: str, html: str = None) -> Optional[str]:
    high_priority = [
        r"https://account\.live\.com/acsr[^\s<>\"'\]]{10,}",
        r"https://account\.live\.com/password/reset[^\s<>\"'\]]{10,}",
        r"https://account\.live\.com/recover[^\s<>\"'\]]{10,}",
        r"https://account\.microsoft\.com/[^\s<>\"'\]]*(?:reset|recover|acsr)[^\s<>\"'\]]{10,}",
        r"https://login\.live\.com/[^\s<>\"'\]]*(?:reset|recover)[^\s<>\"'\]]{10,}",
        r"https://account\.live\.com/[^\s<>\"'\]]*[?&][A-Za-z_]+=\S{8,}",
    ]

    def _scan_patterns(content):
        if not content:
            return None
        for pattern in high_priority:
            m = re.search(pattern, content)
            if m:
                url = m.group(0).rstrip(".,;)\"'\\]")
                if _is_valid_reset_link(url):
                    return url
        return None

    for label, content in [("text", text), ("HTML", html)]:
        result = _scan_patterns(content)
        if result:
            print(f"🎯 Reset link found in {label}: {result[:80]}...")
            return result

    reset_phrases = [
        "click this link to reset your password",
        "reset your password",
        "recover your account",
        "click the link below",
        "account recovery",
    ]

    def _scan_near_phrases(content):
        if not content:
            return None
        lines = content.splitlines()
        for phrase in reset_phrases:
            for i, line in enumerate(lines):
                if phrase.lower() in line.lower():
                    for j in range(i, min(i + 10, len(lines))):
                        for u in re.findall(r"https?://\S+", lines[j]):
                            u = u.rstrip(".,;)\"'\\]")
                            if _is_valid_reset_link(u):
                                return u
        return None

    for content in [text, html]:
        result = _scan_near_phrases(content)
        if result:
            print("🎯 Reset link found near phrase")
            return result

    if html:
        for link in re.findall(r'href=["\']([^"\']+)["\']', html):
            link = link.rstrip(".,;)\"'\\]")
            if _is_valid_reset_link(link):
                print("🎯 Reset link found in HTML href")
                return link

    for label, content in [("text", text), ("HTML", html)]:
        if not content:
            continue
        for u in re.findall(r"https?://\S+", content):
            u = u.rstrip(".,;)\"'\\]")
            if _is_valid_reset_link(u):
                print(f"🎯 Reset link found (last-resort) in {label}")
                return u

    return None
