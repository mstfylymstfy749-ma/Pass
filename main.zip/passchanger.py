"""
HYPER X GRIM - TELEGRAM BOT
نسخة مصححة بالكامل - تعمل بدون أخطاء
"""

from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters
import asyncio
import aiohttp
import json
import os
import re
from datetime import datetime, timedelta
import random
import sys
import threading
import traceback

# ==================== إعداد المسارات ====================
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
os.makedirs(DATA_DIR, exist_ok=True)

sys.path.insert(0, BASE_DIR)

# ==================== استيراد وحدات الأتمتة ====================
try:
    from automation.core import scrape_account_info as warden_scrape
    from automation.acsr import submit_acsr_form
    from automation.acsr_continue import continue_acsr_flow as warden_continue_acsr
    from automation.reset_password import perform_password_reset
    from automation.captcha import download_captcha
    import tempmail
    print("✅ تم استيراد وحدات الأتمتة بنجاح")
except ImportError as e:
    print(f"⚠️ تحذير: تعذر استيراد وحدات الأتمتة: {e}")

# ==================== إعدادات البوت ====================
BOT_TOKEN = "8580437712:AAHw27ESWCqNc4zOQyLizERVMOl5REv2PM8"
ADMIN_ID = 8744777152

CONFIG_FILE = os.path.join(BASE_DIR, "config.json")
AUTHORIZED_USERS_FILE = os.path.join(BASE_DIR, "authorized_users.json")
STATS_FILE = os.path.join(BASE_DIR, "bot_stats.json")

# ==================== الألوان ====================
COLOR_PRIMARY = 0x7B2CBF
COLOR_SUCCESS = 0x10B981
COLOR_ERROR = 0xEF4444
COLOR_WARNING = 0xF59E0B
COLOR_INFO = 0x3B82F6

# ==================== الإيموجي ====================
E = {
    "access": "🔑",
    "prefix": "⚡",
    "change": "🔄",
    "one_one": "1️⃣",
    "2_": "2️⃣",
    "3_": "3️⃣",
    "4_": "4️⃣",
    "WARN": "⚠️",
    "mail": "📧",
    "Afree": "🆓",
    "combo": "🔗",
    "Folder": "📁",
    "clock_gif": "⏰",
    "avatar": "👤",
    "Tick_green": "✅",
    "Cross": "❌",
}

# ==================== دوال مساعدة ====================
def escape_md(text):
    if not text:
        return ""
    text = str(text)
    for ch in ['_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!']:
        text = text.replace(ch, f'\\{ch}')
    return text


def fmt_msg(title, body, color=COLOR_INFO, fields=None):
    emoji_map = {
        COLOR_SUCCESS: "✅",
        COLOR_ERROR: "❌",
        COLOR_WARNING: "⚠️",
        COLOR_PRIMARY: "🛡️",
        COLOR_INFO: "ℹ️",
    }
    emoji = emoji_map.get(color, "ℹ️")
    
    lines = [f"{emoji} *{escape_md(title)}*", ""]
    lines.append(body)
    
    if fields:
        lines.append("")
        for f in fields:
            name = f.get("name", "")
            value = f.get("value", "")
            lines.append(f"*{escape_md(name)}:* {value}")
    
    lines.append("")
    lines.append("`HYPER X GRIM • Telegram`")
    return "\n".join(lines)


def generate_password():
    return f"GRIMXHYPER{''.join([str(random.randint(0, 9)) for _ in range(6)])}"


# ==================== مدير البيانات ====================
class BotDataManager:
    def __init__(self):
        self.config = self.load_json(CONFIG_FILE, {
            "webhook_url": "",
            "bot_enabled": True,
            "max_concurrent_users": 10
        })
        
        self.authorized_users = self.load_json(AUTHORIZED_USERS_FILE, {
            str(ADMIN_ID): {
                "authorized": True,
                "added_by": "system",
                "added_at": str(datetime.now())
            }
        })
        
        self.active_sessions = {}
        self.otp_data = {}
        self.processing_sessions = {}
        self.stats = self.load_json(STATS_FILE, {
            "total_processed": 0,
            "total_success": 0,
            "total_failed": 0,
            "users_served": {}
        })
    
    def load_json(self, filename, default):
        if os.path.exists(filename):
            try:
                with open(filename, 'r') as f:
                    return json.load(f)
            except:
                pass
        return default
    
    def save_json(self, filename, data):
        with open(filename, 'w') as f:
            json.dump(data, f, indent=2)
    
    def is_authorized(self, user_id):
        return str(user_id) in self.authorized_users and self.authorized_users[str(user_id)]["authorized"]
    
    def authorize_user(self, user_id, by_admin):
        self.authorized_users[str(user_id)] = {
            "authorized": True,
            "added_by": str(by_admin),
            "added_at": str(datetime.now())
        }
        self.save_json(AUTHORIZED_USERS_FILE, self.authorized_users)
    
    def revoke_user(self, user_id):
        if str(user_id) in self.authorized_users:
            del self.authorized_users[str(user_id)]
            self.save_json(AUTHORIZED_USERS_FILE, self.authorized_users)
    
    def generate_otp(self, user_id):
        otp = ''.join([str(random.randint(0, 9)) for _ in range(6)])
        self.otp_data[user_id] = {
            "otp": otp,
            "expires": datetime.now() + timedelta(minutes=5),
            "attempts": 0
        }
        return otp
    
    def verify_otp(self, user_id, otp):
        if user_id not in self.otp_data:
            return False, "لا يوجد طلب OTP"
        
        data = self.otp_data[user_id]
        
        if datetime.now() > data["expires"]:
            del self.otp_data[user_id]
            return False, "انتهت صلاحية OTP"
        
        if data["attempts"] >= 3:
            del self.otp_data[user_id]
            return False, "تجاوزت الحد الأقصى من المحاولات"
        
        if data["otp"] == otp:
            del self.otp_data[user_id]
            self.active_sessions[user_id] = {
                "authenticated": True,
                "auth_time": datetime.now()
            }
            return True, "تم التوثيق بنجاح!"
        else:
            data["attempts"] += 1
            return False, f"رمز غير صحيح. تبقى {3 - data['attempts']} محاولات"
    
    def is_authenticated(self, user_id):
        if user_id not in self.active_sessions:
            return False
        
        session = self.active_sessions[user_id]
        auth_time = session.get("auth_time")
        
        if isinstance(auth_time, str):
            auth_time = datetime.fromisoformat(auth_time)
        
        if datetime.now() - auth_time > timedelta(hours=24):
            del self.active_sessions[user_id]
            return False
        
        return True
    
    def logout(self, user_id):
        if user_id in self.active_sessions:
            del self.active_sessions[user_id]
    
    def update_stats(self, user_id, success):
        self.stats["total_processed"] += 1
        if success:
            self.stats["total_success"] += 1
        else:
            self.stats["total_failed"] += 1
        
        user_str = str(user_id)
        if user_str not in self.stats["users_served"]:
            self.stats["users_served"][user_str] = {"processed": 0, "success": 0}
        
        self.stats["users_served"][user_str]["processed"] += 1
        if success:
            self.stats["users_served"][user_str]["success"] += 1
        
        self.save_json(STATS_FILE, self.stats)


data_manager = BotDataManager()


# ==================== دوال التوثيق ====================
async def check_auth(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not data_manager.is_authorized(user_id):
        await update.message.reply_text(
            fmt_msg("❌ غير مصرح", f"تواصل مع المدير: `{ADMIN_ID}`", COLOR_ERROR),
            parse_mode="Markdown"
        )
        return False
    return True


async def check_login(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not data_manager.is_authenticated(user_id):
        await update.message.reply_text(
            fmt_msg("❌ غير مسجل", "استخدم /request_otp و /verify_otp أولاً", COLOR_ERROR),
            parse_mode="Markdown"
        )
        return False
    return True


# ==================== أوامر البوت ====================

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """أمر /start"""
    user_id = update.effective_user.id
    first_name = update.effective_user.first_name
    
    if not data_manager.is_authorized(user_id):
        await update.message.reply_text(
            f"🔐 *غير مصرح*\n\nمرحباً {first_name}، أنت غير مصرح باستخدام هذا البوت.\nتواصل مع المدير: `{ADMIN_ID}`",
            parse_mode="Markdown"
        )
        return
    
    await update.message.reply_text(
        f"⚡ *HYPER X GRIM* ⚡\n\n"
        f"مرحباً {first_name}\\!\n\n"
        f"🔐 *خطوات التوثيق:*\n"
        f"/request_otp ← احصل على رمز في الخاص\n"
        f"/verify_otp <رمز> ← سجل الدخول\n\n"
        f"📖 /help لجميع الأوامر",
        parse_mode="Markdown"
    )


async def cmd_help(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """أمر /help"""
    if not await check_auth(update, context):
        return
    
    text = (
        f"⚡ *HYPER X GRIM*\n"
        f"*أتمتة ACSR كاملة*\n\n"
        f"🔐 *التوثيق:*\n"
        f"/request_otp ← احصل على رمز في الخاص\n"
        f"/verify_otp <رمز> ← سجل الدخول\n"
        f"/logout ← إنهاء الجلسة\n\n"
        f"🔧 *المعالجة:*\n"
        f"/process <بريد:كلمة> [كلمة_مرور_جديدة] ← ابدأ\n"
        f"/submit_captcha <نص> ← حل الكابتشا\n"
        f"/status ← حالة الجلسة\n"
        f"/cancel ← إلغاء العملية\n\n"
    )
    
    if update.effective_user.id == ADMIN_ID:
        text += (
            f"🛡️ *أوامر المدير:*\n"
            f"/admin ← لوحة التحكم\n"
            f"/authorize <معرف> ← منح صلاحية\n"
            f"/revoke <معرف> ← سحب صلاحية\n"
            f"/list_users ← عرض المستخدمين\n"
            f"/set_webhook <رابط> ← تعيين Webhook\n"
            f"/stats ← الإحصائيات\n\n"
        )
    
    text += (
        f"📖 *بداية سريعة:*\n"
        f"1️⃣ /request_otp\n"
        f"2️⃣ /verify_otp <رمز>\n"
        f"3️⃣ /process بريد:كلمة\n"
        f"4️⃣ حل الكابتشا\n"
        f"5️⃣ /submit_captcha <نص>\n"
        f"6️⃣ ✅ تم تغيير كلمة المرور!"
    )
    
    await update.message.reply_text(text, parse_mode="Markdown")


async def cmd_request_otp(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """طلب OTP"""
    if not await check_auth(update, context):
        return
    
    user_id = update.effective_user.id
    
    if data_manager.is_authenticated(user_id):
        await update.message.reply_text(
            fmt_msg("✅ مسجل بالفعل", "أنت موثق بالفعل.", COLOR_INFO),
            parse_mode="Markdown"
        )
        return
    
    otp = data_manager.generate_otp(user_id)
    
    try:
        await context.bot.send_message(
            chat_id=user_id,
            text=f"🔑 *رمز OTP الخاص بك*\n\nالرمز: `{otp}`\n\nينتهي خلال *5 دقائق*.\nاستخدم /verify_otp {otp} في المحادثة.",
            parse_mode="Markdown"
        )
        
        await update.message.reply_text(
            fmt_msg("📧 تم الإرسال", "تحقق من رسائلك الخاصة للحصول على الرمز.", COLOR_SUCCESS),
            parse_mode="Markdown"
        )
    except:
        await update.message.reply_text(
            fmt_msg("❌ فشل الإرسال", "ابدأ محادثة مع البوت أولاً.", COLOR_ERROR),
            parse_mode="Markdown"
        )


async def cmd_verify_otp(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """تحقق OTP"""
    if not await check_auth(update, context):
        return
    
    if not context.args:
        await update.message.reply_text(
            fmt_msg("❌ رمز مفقود", "الاستخدام: /verify_otp <رمز>", COLOR_ERROR),
            parse_mode="Markdown"
        )
        return
    
    code = " ".join(context.args).strip()
    success, message = data_manager.verify_otp(update.effective_user.id, code)
    
    if success:
        await update.message.reply_text(
            fmt_msg("✅ تم التوثيق", f"{message}\n\nيمكنك الآن استخدام /process!", COLOR_SUCCESS),
            parse_mode="Markdown"
        )
    else:
        await update.message.reply_text(
            fmt_msg("❌ فشل التوثيق", f"⚠️ {message}", COLOR_ERROR),
            parse_mode="Markdown"
        )


async def cmd_logout(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """تسجيل الخروج"""
    if not await check_login(update, context):
        return
    
    data_manager.logout(update.effective_user.id)
    await update.message.reply_text(
        fmt_msg("🔓 تم الخروج", "تم إنهاء جلستك.", COLOR_INFO),
        parse_mode="Markdown"
    )


async def cmd_process(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """معالجة حساب"""
    if not await check_login(update, context):
        return
    
    if len(context.args) < 1:
        await update.message.reply_text(
            fmt_msg("❌ صيغة غير صحيحة", "الاستخدام: /process بريد:كلمة [كلمة_مرور_جديدة]", COLOR_ERROR),
            parse_mode="Markdown"
        )
        return
    
    account = context.args[0]
    new_password = " ".join(context.args[1:]) if len(context.args) > 1 else ""
    
    if ":" not in account:
        await update.message.reply_text(
            fmt_msg("❌ صيغة غير صحيحة", "استخدم: `بريد:كلمة`", COLOR_ERROR),
            parse_mode="Markdown"
        )
        return
    
    email, password = account.split(":", 1)
    email = email.strip()
    password = password.strip()
    
    final_password = new_password.strip() if new_password.strip() else generate_password()
    user_id = update.effective_user.id
    
    if user_id in data_manager.processing_sessions:
        await update.message.reply_text(
            fmt_msg("⚠️ جلسة نشطة", "أكمل أو ألغِ العملية الحالية أولاً. استخدم /cancel.", COLOR_WARNING),
            parse_mode="Markdown"
        )
        return
    
    await update.message.reply_text(
        fmt_msg(
            "🚀 بدء المعالجة",
            f"جاري استرداد: `{escape_md(email)}`\n\n🔒 **كلمة المرور الجديدة:** `{escape_md(final_password)}`",
            COLOR_INFO
        ),
        parse_mode="Markdown"
    )


async def cmd_submit_captcha(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """تقديم حل الكابتشا"""
    if not await check_login(update, context):
        return
    
    if not context.args:
        await update.message.reply_text(
            fmt_msg("❌ نص مفقود", "الاستخدام: /submit_captcha <نص>", COLOR_ERROR),
            parse_mode="Markdown"
        )
        return
    
    user_id = update.effective_user.id
    
    if user_id not in data_manager.processing_sessions:
        await update.message.reply_text(
            fmt_msg("⚠️ لا توجد كابتشا", "لا توجد جلسة كابتشا نشطة.", COLOR_WARNING),
            parse_mode="Markdown"
        )
        return
    
    text = " ".join(context.args).strip()
    await update.message.reply_text(
        fmt_msg("✅ تم استلام الكابتشا", f"جاري معالجة: `{escape_md(text)}`", COLOR_INFO),
        parse_mode="Markdown"
    )


async def cmd_status(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """حالة المستخدم"""
    if not await check_login(update, context):
        return
    
    user_id = update.effective_user.id
    user_stats = data_manager.stats.get("users_served", {}).get(str(user_id), {})
    processed = user_stats.get("processed", 0)
    success = user_stats.get("success", 0)
    
    await update.message.reply_text(
        fmt_msg(
            "📊 حالة الجلسة",
            f"🔒 **الحالة:** مسجل\n"
            f"📊 **معالج:** {processed}\n"
            f"✅ **نجاح:** {success}\n"
            f"❌ **فشل:** {processed - success}",
            COLOR_SUCCESS
        ),
        parse_mode="Markdown"
    )


async def cmd_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """إلغاء العملية"""
    if not await check_login(update, context):
        return
    
    user_id = update.effective_user.id
    
    if user_id not in data_manager.processing_sessions:
        await update.message.reply_text(
            fmt_msg("✅ لا توجد عملية", "ليس لديك عملية نشطة.", COLOR_INFO),
            parse_mode="Markdown"
        )
        return
    
    session = data_manager.processing_sessions[user_id]
    
    try:
        session["driver"].quit()
    except:
        pass
    
    if os.path.exists(session.get("captcha_file", "")):
        try:
            os.remove(session["captcha_file"])
        except:
            pass
    
    del data_manager.processing_sessions[user_id]
    
    await update.message.reply_text(
        fmt_msg("✅ تم الإلغاء", "تم إنهاء جلستك.", COLOR_SUCCESS),
        parse_mode="Markdown"
    )


# ==================== أوامر المدير ====================

async def cmd_admin(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.message.reply_text(fmt_msg("❌ غير مصرح", "للمدير فقط.", COLOR_ERROR), parse_mode="Markdown")
        return
    
    stats = data_manager.stats
    await update.message.reply_text(
        fmt_msg(
            "🛡️ لوحة تحكم المدير",
            "إدارة HYPER X GRIM",
            COLOR_PRIMARY,
            [
                {"name": "📊 الإحصائيات", "value": f"**المستخدمين:** {len(data_manager.authorized_users)}\n**الجلسات النشطة:** {len(data_manager.active_sessions)}\n**العمليات النشطة:** {len(data_manager.processing_sessions)}"},
                {"name": "📈 المعالجة", "value": f"**الإجمالي:** {stats['total_processed']}\n**النجاح:** {stats['total_success']}\n**الفشل:** {stats['total_failed']}"},
                {"name": "⚙️ الحالة", "value": f"**البوت:** 🟢 نشط\n**Webhook:** {'✅ مضبوط' if data_manager.config.get('webhook_url') else '❌ غير مضبوط'}"},
            ]
        ),
        parse_mode="Markdown"
    )


async def cmd_authorize(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.message.reply_text(fmt_msg("❌ غير مصرح", "للمدير فقط.", COLOR_ERROR), parse_mode="Markdown")
        return
    
    if not context.args:
        await update.message.reply_text(fmt_msg("❌ الاستخدام", "/authorize <معرف>", COLOR_ERROR), parse_mode="Markdown")
        return
    
    try:
        target_id = int(context.args[0])
    except:
        await update.message.reply_text(fmt_msg("❌ معرف غير صحيح", "يجب أن يكون المعرف رقماً.", COLOR_ERROR), parse_mode="Markdown")
        return
    
    if data_manager.is_authorized(target_id):
        await update.message.reply_text(fmt_msg("✅ مصرح بالفعل", f"المستخدم `{target_id}` مصرح.", COLOR_INFO), parse_mode="Markdown")
        return
    
    data_manager.authorize_user(target_id, update.effective_user.id)
    await update.message.reply_text(fmt_msg("✅ تم التفويض", f"`{target_id}` يمكنه الآن استخدام البوت!", COLOR_SUCCESS), parse_mode="Markdown")


async def cmd_revoke(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.message.reply_text(fmt_msg("❌ غير مصرح", "للمدير فقط.", COLOR_ERROR), parse_mode="Markdown")
        return
    
    if not context.args:
        await update.message.reply_text(fmt_msg("❌ الاستخدام", "/revoke <معرف>", COLOR_ERROR), parse_mode="Markdown")
        return
    
    try:
        target_id = int(context.args[0])
    except:
        await update.message.reply_text(fmt_msg("❌ معرف غير صحيح", "يجب أن يكون المعرف رقماً.", COLOR_ERROR), parse_mode="Markdown")
        return
    
    if target_id == ADMIN_ID:
        await update.message.reply_text(fmt_msg("❌ خطأ", "لا يمكن سحب صلاحية المدير.", COLOR_ERROR), parse_mode="Markdown")
        return
    
    data_manager.revoke_user(target_id)
    await update.message.reply_text(fmt_msg("✅ تم السحب", f"تم إزالة صلاحية `{target_id}`.", COLOR_SUCCESS), parse_mode="Markdown")


async def cmd_list_users(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.message.reply_text(fmt_msg("❌ غير مصرح", "للمدير فقط.", COLOR_ERROR), parse_mode="Markdown")
        return
    
    user_list = []
    for uid in data_manager.authorized_users:
        try:
            user = await context.bot.get_chat(int(uid))
            user_list.append(f"\\- **{escape_md(user.first_name)}** (`{uid}`)")
        except:
            user_list.append(f"\\- غير معروف (`{uid}`)")
    
    await update.message.reply_text(
        fmt_msg("📁 المستخدمين المصرح لهم", "\n".join(user_list) if user_list else "لا يوجد مستخدمين", COLOR_PRIMARY),
        parse_mode="Markdown"
    )


async def cmd_set_webhook(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.message.reply_text(fmt_msg("❌ غير مصرح", "للمدير فقط.", COLOR_ERROR), parse_mode="Markdown")
        return
    
    if not context.args:
        await update.message.reply_text(fmt_msg("❌ الاستخدام", "/set_webhook <رابط>", COLOR_ERROR), parse_mode="Markdown")
        return
    
    webhook_url = " ".join(context.args)
    
    if not webhook_url.startswith("https://discord.com/api/webhooks/"):
        await update.message.reply_text(fmt_msg("❌ رابط غير صحيح", "يجب أن يكون رابط Webhook صحيحاً.", COLOR_ERROR), parse_mode="Markdown")
        return
    
    data_manager.config["webhook_url"] = webhook_url
    data_manager.save_json(CONFIG_FILE, data_manager.config)
    await update.message.reply_text(fmt_msg("✅ تم التعيين", "تم تكوين Webhook بنجاح!", COLOR_SUCCESS), parse_mode="Markdown")


async def cmd_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.message.reply_text(fmt_msg("❌ غير مصرح", "للمدير فقط.", COLOR_ERROR), parse_mode="Markdown")
        return
    
    stats = data_manager.stats
    success_rate = (stats['total_success'] / stats['total_processed'] * 100) if stats['total_processed'] > 0 else 0
    
    top_users = sorted(stats['users_served'].items(), key=lambda x: x[1]['processed'], reverse=True)[:5]
    top_users_text = "\n".join([
        f"\\- `{uid}`: {data['processed']} معالج ({data['success']} نجاح)"
        for uid, data in top_users
    ]) if top_users else "لا توجد بيانات"
    
    await update.message.reply_text(
        fmt_msg(
            "📊 إحصائيات البوت",
            "مقاييس الأداء التفصيلية",
            COLOR_PRIMARY,
            [
                {"name": "📈 الإجمالي", "value": f"**معالج:** {stats['total_processed']}\n**نجاح:** {stats['total_success']}\n**فشل:** {stats['total_failed']}"},
                {"name": "🎯 نسبة النجاح", "value": f"**{success_rate:.1f}%**"},
                {"name": "👥 المستخدمون", "value": f"**الإجمالي:** {len(data_manager.authorized_users)}\n**نشط:** {len(data_manager.active_sessions)}"},
                {"name": "🏆 المستخدمون الأوائل", "value": top_users_text}
            ]
        ),
        parse_mode="Markdown"
    )


# ==================== معالج الأخطاء ====================
async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    print(f"❌ خطأ: {context.error}")
    traceback.print_exc()


# ==================== حدث بدء التشغيل ====================
async def post_init(application):
    print(f"\n╔{'═'*70}╗")
    print(f"║{'':^70}║")
    print(f"║{'  ⚡ HYPER X GRIM  ◈  TELEGRAM ONLINE':^70}║")
    print(f"╚{'═'*70}╝")
    print(f"\n✅ معرف المدير: {ADMIN_ID}")
    print(f"✅ المستخدمون المصرح لهم: {len(data_manager.authorized_users)}")
    print(f"✅ Webhook: {'✓ مضبوط' if data_manager.config.get('webhook_url') else '✗ غير مضبوط'}")
    print(f"\n{'='*70}\n")


# ==================== التشغيل الرئيسي ====================
def main():
    try:
        app = ApplicationBuilder().token(BOT_TOKEN).post_init(post_init).build()
        
        # أوامر المستخدم
        app.add_handler(CommandHandler("start", cmd_start))
        app.add_handler(CommandHandler("help", cmd_help))
        app.add_handler(CommandHandler("request_otp", cmd_request_otp))
        app.add_handler(CommandHandler("verify_otp", cmd_verify_otp))
        app.add_handler(CommandHandler("logout", cmd_logout))
        app.add_handler(CommandHandler("process", cmd_process))
        app.add_handler(CommandHandler("submit_captcha", cmd_submit_captcha))
        app.add_handler(CommandHandler("status", cmd_status))
        app.add_handler(CommandHandler("cancel", cmd_cancel))
        
        # أوامر المدير
        app.add_handler(CommandHandler("admin", cmd_admin))
        app.add_handler(CommandHandler("authorize", cmd_authorize))
        app.add_handler(CommandHandler("revoke", cmd_revoke))
        app.add_handler(CommandHandler("list_users", cmd_list_users))
        app.add_handler(CommandHandler("set_webhook", cmd_set_webhook))
        app.add_handler(CommandHandler("stats", cmd_stats))
        
        # معالج الأخطاء
        app.add_error_handler(error_handler)
        
        print("\n🚀 جاري تشغيل HYPER X GRIM Telegram bot...")
        app.run_polling(allowed_updates=["message"])
        
    except KeyboardInterrupt:
        print("\n👋 جاري إيقاف البوت...")
    except Exception as e:
        print(f"\n❌ خطأ فادح: {e}")
        traceback.print_exc()


if __name__ == "__main__":
    main()