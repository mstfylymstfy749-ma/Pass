# MS Password Changer — Telegram Bot

Full port of the Discord bot to Telegram using `python-telegram-bot` v20+.

---

## Setup

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure
Either set environment variables:
```bash
export BOT_TOKEN="7123456789:AAH..."
export ADMIN_TELEGRAM_ID="123456789"
```
Or edit the constants at the top of `bot.py`.

### 3. Run
```bash
# With env vars already set:
python bot.py

# Or pass as CLI args:
python bot.py <BOT_TOKEN> <ADMIN_TELEGRAM_ID>
```

---

## Commands

| Command | Description |
|---|---|
| `/start` | Welcome screen + inline menu |
| `/help` | Full command reference |
| `/request_otp` | Receive a 6-digit OTP via DM |
| `/verify_otp <code>` | Authenticate with OTP |
| `/logout` | End session |
| `/process email:pass` | Start account processing |
| `/submit_captcha <text>` | Solve the CAPTCHA |
| `/status` | Show session state |
| `/cancel` | Abort active process |
| `/admin` | Admin panel (admin only) |
| `/authorize <uid>` | Grant access (admin only) |
| `/revoke <uid>` | Remove access (admin only) |
| `/list_users` | List authorized users (admin only) |
| `/set_webhook <url>` | Set Discord webhook for results (admin only) |
| `/stats` | Bot statistics (admin only) |

---

## Project Structure

```
TelegramPassChanger/
├── bot.py                  ← Main Telegram bot (this file)
├── tempmail.py             ← Temp email (mail.tm API)
├── requirements.txt
├── README.md
├── automation/
│   ├── core.py             ← MS account scraper (Selenium)
│   ├── acsr.py             ← ACSR form submission
│   ├── acsr_continue.py    ← Post-CAPTCHA ACSR flow
│   ├── reset_password.py   ← Password reset via link
│   ├── captcha.py          ← CAPTCHA image downloader
│   ├── driver.py           ← Chrome WebDriver factory
│   └── logger.py
├── utils/
│   ├── api_client.py
│   ├── session_manager.py
│   └── password_generator.py
└── data/                   ← Auto-created at runtime
    ├── bot_config.json
    ├── authorized_users.json
    ├── bot_stats.json
    ├── bot.log
    └── captchas/
```
